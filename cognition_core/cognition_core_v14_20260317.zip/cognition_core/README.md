# Cognition Core v13 — Architecture complète

## Fichiers

### Modules Python
| Fichier | Version | Rôle |
|---------|---------|------|
| cognition_core.py | 13.0.0 | Noyau cognitif — pipeline, graphe, queues, préférences |
| nlp_parser.py | 2.0.0 | Parseur spaCy + LLM fallback (ollama/anthropic) |
| grammar_engine.py | 1.0.0 | Grammaire de réécriture française + prosodie + stream |
| sentence_builder.py | 2.0.0 | GrammarBuilder — intent → texte ou stream temps réel |
| production_stream.py | 1.0.0 | Deux queues parallèles : TTS temps réel + texte complet |
| narrative_store.py | 1.0.0 | Mémoire narrative immuable livre/chapitre/section/page |
| french_morphology.py | 1.0.0 | Morphologie française — élisions, accords, articles |

### Configuration
| Fichier | Rôle |
|---------|------|
| gem.json | Personnalité : resonances, poids, seuil_rejet, llm_fallback |

### Patterns NLP (patterns/)
| Fichier | Domaine |
|---------|---------|
| temps.json | Heure, date, intervalles temporels |
| social.json | Salutations, remerciements, congés |
| personnes.json | Identité, relations, localisation |
| actions.json | Rappels, engagements, demandes d'action |
| preferences.json | Aimer / ne pas aimer / indifférent |

### Bases de connaissance (bases/)
| Fichier | Contenu |
|---------|---------|
| monde_physique.json | Espace, temps, lumière, eau, corps |
| emotions.json | Joie, tristesse, peur, colère, curiosité, sérénité |
| relations_sociales.json | Ami, famille, confiance, conversation, gratitude |
| vie_quotidienne.json | Repas, maison, travail, sommeil, déplacement |
| nature.json | Saisons, météo, animaux, arbres |
| concepts_abstraits.json | Vérité, beauté, liberté, existence, changement |

## Dépendances

```bash
pip install spacy
python -m spacy download fr_core_news_sm

# LLM fallback (optionnel, offline)
# Installer ollama : https://ollama.com
# puis : ollama pull mistral
```

## Option globale LLM fallback

Dans `cognition_core.py`, ligne ~50 :
```python
USE_LLM_FALLBACK: bool = True   # mettre False pour désactiver
```

Ou à l'exécution :
```python
import cognition_core
cognition_core.USE_LLM_FALLBACK = False
```

Provider configuré dans `gem.json` → `llm_fallback` :
```json
"llm_fallback": {
    "provider":  "ollama",    // "ollama" (local) ou "anthropic" (API)
    "model":     "mistral",   // modèle ollama : mistral, phi3, gemma2...
    "threshold": 0.5,         // confiance spaCy en dessous de laquelle le LLM est appelé
    "timeout":   5            // secondes max (court — c'est un fallback)
}
```

## Usage

```python
from cognition_core import CognitionCore
from pathlib import Path

# Désactiver LLM si non disponible
import cognition_core
cognition_core.USE_LLM_FALLBACK = False  # optionnel

core = CognitionCore(
    data_path     = Path("./data"),
    gem_path      = Path("./gem.json"),
    patterns_dir  = Path("./patterns"),
    narrative_dir = Path("./narrative")
)

for base in ["monde_physique", "emotions", "relations_sociales",
             "vie_quotidienne", "nature", "concepts_abstraits"]:
    core.load_knowledge_base(base, Path(f"./bases/{base}.json"))

core.start()

# Mode batch
texte = core.process("tu aimes les chiens ?",
                     input_type="text", output_type="text")

# Mode stream (deux consommateurs parallèles)
intent = core.process("bonjour", input_type="text", output_type="intent")
stream = core.builder.build_stream(intent)

for token in stream.iter_tokens():   # → TTS temps réel
    print(token.word, token.duration_ms)

full_text = stream.get_text()        # → mémoire / log

# Interruption depuis couche perceptive
from production_stream import InterruptReason
stream.interrupt(InterruptReason.PERCEPTION)

# Entrée narrative externe (fire-and-forget)
core.push_narrative(intent, source="perception")

# Consommateur d'actions (planificateur externe)
while True:
    actionable = core.action_queue.get()
    planner.handle(actionable)
```

## Architecture des préférences (v13)

```
PreferenceState : NE_SAIT_PAS | INDIFFERENT | NEUTRE | AIME | AIME_PAS

Calcul futur (PreferenceEngine — à brancher) :
  preference = α · resonance(Gem, concept)          # tempérament
             + β · agregat(narrative, concept,       # expériences
                           dispersion_temporelle)    # distillées dans le temps
             + γ · affect_courant                    # état du moment

  avec seuil_rejet : si resonance < seuil → imperméable aux corrections

Dimensions de résonance partagées Gem ↔ fiches :
  complexite, imprevisibilite, intensite, sensorialite, partage,
  rythme, ordre, chaleur, ancrage, familiarite
```

## Philosophie
*Sensio ergo sum* — la perception précède la représentation.
L'état affectif VAD traverse toute la production jusqu'aux durées des syllabes.
Les préférences émergent de la résonance entre le Gem et le monde perçu,
modulées par les expériences distillées dans le temps.
