"""
production_stream.py — Flux de production temps réel
Version 1.0.0

Deux queues en parallèle :
  - token_queue  : SpeechToken émis au fil de la réalisation (consommée par TTS)
  - text_queue   : texte complet assemblé et livré à la fin (consommée par le log/mémoire)

Interruption et correction :
  - interrupt()  : signal d'arrêt propre (finit le GrammarNode en cours)
  - inject()     : insère des tokens de correction après l'émission courante

Le producteur (GrammarEngine) teste stream.interrupted à chaque terminal émis.
Le consommateur TTS lit token_queue sans attendre la fin.
Le consommateur texte attend text_queue.get() qui se débloque quand done() est appelé.

Usage côté producteur :
    stream = ProductionStream()
    for token in prosody.stream(node, affect):
        if stream.interrupted:
            token = stream.closing_token()   # token de clôture propre
            stream.put_token(token)
            break
        stream.put_token(token)
    stream.done()

Usage côté consommateur TTS :
    while True:
        token = stream.token_queue.get()
        if token is END_OF_STREAM:
            break
        tts.speak(token)

Usage côté consommateur texte :
    full_text = stream.text_queue.get()   # bloquant jusqu'à done()
"""

import queue
import threading
import time
import logging
from dataclasses import dataclass, field
from typing import Optional, List, Iterator
from enum import Enum

logger = logging.getLogger("ProductionStream")


# ============================================================
# SENTINELLE DE FIN DE FLUX
# ============================================================

class _EndOfStream:
    """Objet sentinelle placé dans token_queue pour signaler la fin."""
    pass

END_OF_STREAM = _EndOfStream()


# ============================================================
# RAISON D'INTERRUPTION
# ============================================================

class InterruptReason(str, Enum):
    PERCEPTION        = "perception"        # signal perceptif entrant
    AFFECT_SHIFT      = "affect_shift"      # changement d'état affectif brutal
    PRIORITY_INTENT   = "priority_intent"   # intent prioritaire reçu
    TIMEOUT           = "timeout"           # délai dépassé
    EXTERNAL          = "external"          # signal externe générique


# ============================================================
# TOKEN DE CLÔTURE
# ============================================================

def closing_token_for(reason: InterruptReason):
    """
    Retourne un SpeechToken de clôture selon la raison d'interruption.
    Importé ici pour éviter la dépendance circulaire — le caller importe
    SpeechToken depuis grammar_engine et passe le constructeur.
    """
    # La logique est dans ProductionStream.get_closing_token()
    # ce module ne dépend pas de grammar_engine
    pass


# ============================================================
# PRODUCTION STREAM
# ============================================================

class ProductionStream:
    """
    Canal de production temps réel.

    Deux queues :
      token_queue : SpeechToken | END_OF_STREAM  (non bloquant côté put)
      text_queue  : str                           (bloquant jusqu'à done())

    Thread-safe. Le producteur et le consommateur TTS tournent
    dans des threads différents.
    """

    def __init__(self, maxsize: int = 64):
        """
        maxsize : taille max de token_queue (backpressure si TTS est lent)
        """
        self.token_queue: queue.Queue = queue.Queue(maxsize=maxsize)
        self.text_queue:  queue.Queue = queue.Queue(maxsize=1)

        self._interrupted:       bool                    = False
        self._interrupt_reason:  Optional[InterruptReason] = None
        self._interrupt_event:   threading.Event         = threading.Event()

        self._tokens_emitted:    List = []   # buffer pour assemblage texte
        self._correction_buffer: List = []   # tokens de correction en attente
        self._lock:              threading.Lock = threading.Lock()

        self._start_time: float = time.monotonic()
        self._done:       bool  = False

    # ----------------------------------------------------------
    # INTERFACE PRODUCTEUR
    # ----------------------------------------------------------

    def put_token(self, token) -> bool:
        """
        Émet un SpeechToken dans la queue.
        Retourne False si interrompu (le producteur doit s'arrêter).
        """
        if self._interrupted:
            return False

        # Injecter les corrections en attente d'abord
        with self._lock:
            if self._correction_buffer:
                for corr_token in self._correction_buffer:
                    self.token_queue.put(corr_token)
                    self._tokens_emitted.append(corr_token)
                self._correction_buffer.clear()

        self.token_queue.put(token)
        with self._lock:
            self._tokens_emitted.append(token)

        return True

    def done(self):
        """
        Signale la fin de production.
        Assemble le texte complet et le dépose dans text_queue.
        Émet END_OF_STREAM dans token_queue.
        """
        if self._done:
            return

        self._done = True

        # Assembler le texte complet depuis les tokens émis
        full_text = self._assemble_text()
        self.text_queue.put(full_text)

        # Signaler la fin au consommateur TTS
        self.token_queue.put(END_OF_STREAM)

        elapsed = time.monotonic() - self._start_time
        logger.debug(
            f"Stream terminé — {len(self._tokens_emitted)} tokens, "
            f"{elapsed*1000:.0f}ms, texte: '{full_text[:60]}'"
        )

    @property
    def interrupted(self) -> bool:
        return self._interrupted

    @property
    def interrupt_reason(self) -> Optional[InterruptReason]:
        return self._interrupt_reason

    def get_closing_token(self, SpeechTokenClass, ProsodyRoleClass):
        """
        Retourne un token de clôture prosodique adapté à la raison
        d'interruption. Le caller passe les classes pour éviter
        la dépendance circulaire.

        Raison PERCEPTION / PRIORITY_INTENT → coupure nette (pause longue)
        Raison AFFECT_SHIFT                 → suspension douce (…)
        Raison TIMEOUT                      → point final
        """
        reason = self._interrupt_reason or InterruptReason.EXTERNAL

        if reason in (InterruptReason.PERCEPTION,
                      InterruptReason.PRIORITY_INTENT):
            # Coupure nette — silence court puis reprise
            return SpeechTokenClass(
                word="",
                duration_ms=0,
                accent=0.0,
                pitch_delta=0.0,
                pause_after=200,
                role=ProsodyRoleClass.PONCTUATION
            )
        elif reason == InterruptReason.AFFECT_SHIFT:
            # Suspension — "…" audible
            return SpeechTokenClass(
                word="…",
                duration_ms=0,
                accent=0.0,
                pitch_delta=-0.1,
                pause_after=500,
                role=ProsodyRoleClass.PONCTUATION
            )
        else:
            # Clôture propre — point final
            return SpeechTokenClass(
                word=".",
                duration_ms=0,
                accent=0.0,
                pitch_delta=0.0,
                pause_after=350,
                role=ProsodyRoleClass.PONCTUATION
            )

    # ----------------------------------------------------------
    # INTERFACE CONTRÔLEUR (couche cognitive / perceptive)
    # ----------------------------------------------------------

    def interrupt(self, reason: InterruptReason = InterruptReason.EXTERNAL):
        """
        Demande une interruption propre.
        Le producteur finira le GrammarNode en cours avant de s'arrêter.
        """
        if self._done or self._interrupted:
            return

        logger.debug(f"Interruption demandée : {reason.value}")
        with self._lock:
            self._interrupted = True
            self._interrupt_reason = reason
        self._interrupt_event.set()

    def inject(self, tokens: list):
        """
        Injecte des tokens de correction dans le flux.
        Ils seront émis au prochain put_token() du producteur.
        Typiquement : hésitation ("enfin…"), correction ("je veux dire"),
        reprise après interruption.
        """
        with self._lock:
            self._correction_buffer.extend(tokens)
        logger.debug(f"{len(tokens)} tokens de correction injectés")

    def wait_interrupt(self, timeout: float = None) -> bool:
        """
        Bloque jusqu'à ce qu'une interruption soit demandée.
        Retourne True si interruption, False si timeout.
        Utile pour les workers qui surveillent le flux.
        """
        return self._interrupt_event.wait(timeout=timeout)

    # ----------------------------------------------------------
    # INTERFACE CONSOMMATEUR
    # ----------------------------------------------------------

    def iter_tokens(self) -> Iterator:
        """
        Itérateur sur les SpeechToken.
        S'arrête à END_OF_STREAM.

        Usage :
            for token in stream.iter_tokens():
                tts.speak(token)
        """
        while True:
            token = self.token_queue.get()
            if isinstance(token, _EndOfStream):
                break
            yield token

    def get_text(self, timeout: float = 30.0) -> Optional[str]:
        """
        Bloque jusqu'à ce que le texte complet soit disponible.
        Retourne None si timeout dépassé.
        """
        try:
            return self.text_queue.get(timeout=timeout)
        except queue.Empty:
            logger.warning("Timeout en attente du texte complet")
            return None

    # ----------------------------------------------------------
    # ÉTAT
    # ----------------------------------------------------------

    @property
    def is_done(self) -> bool:
        return self._done

    @property
    def tokens_emitted(self) -> int:
        return len(self._tokens_emitted)

    def elapsed_ms(self) -> float:
        return (time.monotonic() - self._start_time) * 1000

    # ----------------------------------------------------------
    # ASSEMBLAGE TEXTE
    # ----------------------------------------------------------

    def _assemble_text(self) -> str:
        """
        Assemble le texte depuis les tokens émis.
        Gère la ponctuation (pas d'espace avant) et les tokens vides.
        """
        PUNCT = set(".,!?;:…—")
        parts = []

        for token in self._tokens_emitted:
            word = getattr(token, "word", str(token))
            if not word:
                continue
            if word in PUNCT:
                if parts:
                    parts[-1] = parts[-1].rstrip(" ")
                parts.append(word)
            else:
                parts.append(word)

        text = " ".join(parts)
        # Nettoyage
        import re
        text = re.sub(r" ([.,!?;:…—])", r"\1", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text


# ============================================================
# STREAM SYNCHRONE (pour les cas simples / tests)
# ============================================================

class SyncProductionStream(ProductionStream):
    """
    Version synchrone de ProductionStream pour les contextes
    où l'on ne veut pas de threading.
    Collecte tous les tokens, text_queue se remplit immédiatement à done().
    """

    def iter_tokens_sync(self) -> list:
        """Retourne tous les tokens collectés après done()."""
        return list(self._tokens_emitted)
