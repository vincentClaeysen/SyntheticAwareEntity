"""
cognition_core.py — Cœur cognitif refactorisé
Version 14.0.0

Changements vs v13 :
- AffectiveDrift    : dérive lente du VAD selon le contenu conversationnel
- ConversationSummary : résumé sémantique du fil conversationnel
- _generate_curiosity : questions spontanées pilotées par curiosite_* du Gem
- _cognize enrichi  : dérive affective + curiosité après chaque tour
- _update_context_summary : mise à jour légère du fil à chaque turn
"""

# ============================================================
# IMPORTS (à fusionner avec les imports existants de v10)
# ============================================================
# Les imports ci-dessous s'ajoutent / remplacent dans cognition_core.py

import json
import logging
import time
import uuid
import threading
import queue
import sqlite3
import gzip
import pickle
import re
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Set, Union
from dataclasses import dataclass, field, asdict
from enum import Enum
from collections import defaultdict, OrderedDict
from abc import ABC, abstractmethod
import hashlib

# Nouveaux imports
from nlp_parser import IntentParser, ParseResult
from sentence_builder import GrammarBuilder
from french_morphology import FrenchMorphology
from narrative_store import NarrativeStore

# Tous les modèles v10 restent identiques (Concept, Gem, ContextFrame, etc.)
# On ne redéfinit ici que CognitionCore et ce qui change.

__version__ = "14.0.0"
logger = logging.getLogger("CognitionCore")

# ============================================================
# OPTION GLOBALE — LLM FALLBACK
# ============================================================
# Mettre à False pour désactiver complètement le LLM fallback
# dans tout le pipeline, sans modifier le reste du code.
# Peut aussi être surchargé à l'exécution :
#   import cognition_core; cognition_core.USE_LLM_FALLBACK = False
USE_LLM_FALLBACK: bool = True

# ============================================================
# CONSERVATION INTÉGRALE DE v10
# (IntentType, RelationType, SourceWeight, ConceptNature, MemoryType,
#  StorageLevel, SourceInfo, Relation, Propriete, Concept, Attribute,
#  StructuredIntent, ContextFrame, SystemContext,
#  CompressedStorage, KnowledgeGraph)
#
# → Copier-coller depuis cognition_core v10 sans modification.
# ============================================================

# ============================================================
# ÉTAT DE PRÉFÉRENCE
# ============================================================

class PreferenceState(str, Enum):
    """
    État de préférence de l'entité envers un concept ou une instance.

    AIME         : évaluation positive — résonance et/ou expériences favorables
    AIME_PAS     : évaluation négative — résonance faible et/ou expériences défavorables
    NEUTRE       : évalué, les dimensions positives et négatives s'équilibrent
    INDIFFERENT  : rencontré mais sans résonance significative ni expériences marquantes
    NE_SAIT_PAS  : pas encore suffisamment rencontré pour former une évaluation

    Distinction clé :
      INDIFFERENT ≠ NE_SAIT_PAS
      INDIFFERENT = connu, évalué, pas de résonance particulière
      NE_SAIT_PAS = insuffisamment connu pour évaluer
      NEUTRE      = évalué, tensions équilibrées (peut basculer)
    """
    AIME        = "aime"
    AIME_PAS    = "aime_pas"
    NEUTRE      = "neutre"
    INDIFFERENT = "indifferent"
    NE_SAIT_PAS = "ne_sait_pas"


# Noms des dimensions de résonance partagées Gem ↔ fiches de connaissance
RESONANCE_DIMS = [
    "complexite",
    "imprevisibilite",
    "intensite",
    "sensorialite",
    "partage",
    "rythme",
    "ordre",
    "chaleur",
    "ancrage",
    "familiarite"
]


# ============================================================
# DÉRIVE AFFECTIVE — VAD DYNAMIQUE SANS SOMACORE
# ============================================================

@dataclass
class AffectiveDrift:
    """
    Dérive lente de l'état affectif VAD selon le contenu conversationnel.

    Sans SomaCore, c'est une heuristique légère — pas de signal somatique
    réel, mais une approximation cohérente avec l'architecture :
    l'état dérive sous l'influence des échanges, avec inertie.

    L'inertie empêche les sauts brutaux — *Sensio ergo sum* implique
    que l'état émotionnel n'est pas une variable discrète.

    Pilotage :
      - Concept connu + valence positive  → valence +delta
      - Concept inconnu + curiosité haute → arousal +delta
      - Ambiguïté répétée                → dominance -delta
      - Curiosité satisfaite (réponse ok) → arousal -delta
      - Sujet de préférence forte         → valence ±delta selon état
    """

    valence:   float = 0.0
    arousal:   float = 0.3
    dominance: float = 0.6

    # Inertie : plus c'est élevé, plus la dérive est lente
    inertie: float = 0.85

    # Historique pour calcul de tendance
    _history: List[Dict] = field(default_factory=list)

    def drift(self, delta_v: float = 0.0,
              delta_a: float = 0.0,
              delta_d: float = 0.0):
        """
        Applique une dérive avec inertie.
        Les deltas sont atténués par l'inertie avant application.
        """
        # Atténuation
        dv = delta_v * (1.0 - self.inertie)
        da = delta_a * (1.0 - self.inertie)
        dd = delta_d * (1.0 - self.inertie)

        # Application avec clamp [-1, 1] / [0, 1]
        self.valence   = max(-1.0, min(1.0, self.valence   + dv))
        self.arousal   = max(0.0,  min(1.0, self.arousal   + da))
        self.dominance = max(0.0,  min(1.0, self.dominance + dd))

        # Enregistrer
        self._history.append({
            "timestamp": time.time(),
            "valence":   round(self.valence,   3),
            "arousal":   round(self.arousal,   3),
            "dominance": round(self.dominance, 3)
        })
        # Garder 100 points max
        if len(self._history) > 100:
            self._history = self._history[-100:]

    def retour_equilibre(self, taux: float = 0.02):
        """
        Dérive lente vers l'état d'équilibre du Gem.
        Appelé périodiquement — entre les échanges.
        """
        self.drift(
            delta_v = -self.valence   * taux,
            delta_a = (0.3 - self.arousal)   * taux,
            delta_d = (0.6 - self.dominance) * taux
        )

    def snapshot(self) -> Dict[str, float]:
        return {
            "valence":   round(self.valence,   3),
            "arousal":   round(self.arousal,   3),
            "dominance": round(self.dominance, 3)
        }


# ============================================================
# RÉSUMÉ CONVERSATIONNEL
# ============================================================

@dataclass
class ConversationSummary:
    """
    Résumé sémantique léger du fil conversationnel.
    Mis à jour à chaque tour — extraction rapide, sans LLM.

    Contient :
    - sujets_abordes   : concepts mentionnés dans l'échange
    - questions_ouvertes : questions posées sans réponse complète
    - valence_dominante : tendance affective de la conversation
    - derniere_curiosite : dernier concept sur lequel l'entité a été curieuse
    - tours             : nombre de tours échangés
    """
    sujets_abordes:    List[str]  = field(default_factory=list)
    questions_ouvertes: List[str] = field(default_factory=list)
    valence_dominante: float      = 0.0
    derniere_curiosite: Optional[str] = None
    tours:             int        = 0
    _valences:         List[float] = field(default_factory=list)

    def ajouter_sujet(self, sujet: str):
        if sujet and sujet not in self.sujets_abordes:
            self.sujets_abordes.append(sujet)
            # Garder les 20 derniers
            self.sujets_abordes = self.sujets_abordes[-20:]

    def ajouter_question_ouverte(self, question: str):
        if question not in self.questions_ouvertes:
            self.questions_ouvertes.append(question)
            self.questions_ouvertes = self.questions_ouvertes[-5:]

    def fermer_question(self, sujet: str):
        """Retire les questions ouvertes liées à un sujet."""
        self.questions_ouvertes = [
            q for q in self.questions_ouvertes
            if sujet.lower() not in q.lower()
        ]

    def noter_valence(self, valence: float):
        self._valences.append(valence)
        self._valences = self._valences[-20:]
        self.valence_dominante = round(
            sum(self._valences) / len(self._valences), 3
        ) if self._valences else 0.0

    def incrementer_tour(self):
        self.tours += 1

    def to_context_string(self) -> str:
        """Résumé textuel compact pour le LLM fallback si besoin."""
        parts = []
        if self.sujets_abordes:
            parts.append(f"Sujets : {', '.join(self.sujets_abordes[-5:])}")
        if self.questions_ouvertes:
            parts.append(f"Questions ouvertes : {'; '.join(self.questions_ouvertes)}")
        if self.derniere_curiosite:
            parts.append(f"Curiosité récente : {self.derniere_curiosite}")
        parts.append(f"Tours : {self.tours}")
        return " | ".join(parts)


# ============================================================
# EXTENSIONS GEM (à ajouter dans Gem.from_file)
# ============================================================
# Ces champs sont lus depuis gem.json si présents,
# sinon valeurs par défaut.
#
# "resonances": {
#     "complexite": 0.8, "imprevisibilite": 0.7, "intensite": 0.7,
#     "sensorialite": 0.5, "partage": 0.8, "rythme": 0.5,
#     "ordre": 0.4, "chaleur": 0.7, "ancrage": 0.6, "familiarite": 0.4
# },
# "seuil_rejet": 0.25,
# "poids_resonance": 0.5,
# "poids_experience": 0.35,
# "poids_affect": 0.15
#
# → Gem.from_file() lit ces champs via g.get("resonances", {...})
#   La classe Gem existante est étendue sans rupture.
# ============================================================


# ============================================================
# PATTERN VISITEUR — TRAITEMENT DES INTENTS D'INFORMATION
# ============================================================

@dataclass
class EntiteDetectee:
    """
    Une entité détectée dans un intent.
    Peut venir des attributs parsés ou des entités NER brutes.
    """
    nom:        str
    nature:     "ConceptNature"
    mem_type:   "MemoryType"
    source_ner: str = ""          # label NER original ("PER", "LOC"...)
    valeur:     Any = None        # valeur brute si propriété
    confiance:  float = 0.8


@dataclass
class RelationDetectee:
    """Une relation inférée entre deux entités."""
    sujet:   str
    type:    "RelationType"
    cible:   str
    confiance: float = 0.7


@dataclass
class ProprieteDetectee:
    """Une propriété détectée sur une entité."""
    concept: str
    nom:     str
    valeur:  Any
    type_val: str = "texte"
    confiance: float = 0.8


@dataclass
class AnalyseIntent:
    """
    Résultat de l'analyse d'un intent par IntentAnalyzer.
    Contient toutes les entités, relations et propriétés détectées.
    """
    entites:    List[EntiteDetectee]    = field(default_factory=list)
    relations:  List[RelationDetectee]  = field(default_factory=list)
    proprietes: List[ProprieteDetectee] = field(default_factory=list)
    source:     Any = None              # SourceInfo


class IntentVisitor(ABC):
    """
    Interface visiteur pour le traitement des intents d'information.

    Implémentations possibles :
      GraphStorageVisitor   — écrit dans le KnowledgeGraph
      NarrativeVisitor      — décide si l'info mérite d'être narrativisée
      PreferenceVisitor     — détecte les valences affectives
      ActionVisitor         — détecte les engagements actionnables
    """

    @abstractmethod
    def visit_entite(self, e: EntiteDetectee, source) -> None:
        """Visite une entité détectée."""
        ...

    @abstractmethod
    def visit_relation(self, r: RelationDetectee, source) -> None:
        """Visite une relation détectée."""
        ...

    @abstractmethod
    def visit_propriete(self, p: ProprieteDetectee, source) -> None:
        """Visite une propriété détectée."""
        ...

    def begin(self, intent, analyse: "AnalyseIntent") -> None:
        """Appelé avant la visite — optionnel."""
        pass

    def end(self, intent, analyse: "AnalyseIntent") -> None:
        """Appelé après la visite — optionnel."""
        pass


class IntentAnalyzer:
    """
    Analyse un StructuredIntent et produit une AnalyseIntent.
    Appelle ensuite les visiteurs enregistrés sur chaque élément.

    Extensible : ajouter une analyse = ajouter _analyze_xxx.
    Extensible : ajouter un comportement = ajouter un visiteur.
    """

    # Mapping NER label → (ConceptNature, MemoryType)
    NER_NATURE_MAP: Dict[str, Tuple] = {
        "PER":    ("personne",   "social"),
        "PERSON": ("personne",   "social"),
        "LOC":    ("lieu",       "permanent"),
        "GPE":    ("lieu",       "permanent"),
        "FAC":    ("lieu",       "permanent"),
        "ORG":    ("categorie",  "permanent"),
        "DATE":   ("intervalle", "episodique"),
        "TIME":   ("point",      "episodique"),
        "MISC":   ("instance",   "episodique"),
        "PROD":   ("objet",      "episodique"),
        "EVENT":  ("action",     "episodique"),
    }

    # Mapping relation textuelle → RelationType
    RELATION_MAP: Dict[str, str] = {
        # Famille
        "frère":      "est_parent_de",  "sœur":        "est_parent_de",
        "soeur":      "est_parent_de",  "père":        "est_parent_de",
        "mere":       "est_parent_de",  "mère":        "est_parent_de",
        "pere":       "est_parent_de",  "fils":        "est_parent_de",
        "fille":      "est_parent_de",  "parent":      "est_parent_de",
        "enfant":     "est_parent_de",  "oncle":       "est_parent_de",
        "tante":      "est_parent_de",  "cousin":      "est_parent_de",
        "cousine":    "est_parent_de",  "neveu":       "est_parent_de",
        "nièce":      "est_parent_de",
        # Social
        "ami":        "est_ami_de",     "amie":        "est_ami_de",
        "copain":     "est_ami_de",     "copine":      "est_ami_de",
        "collègue":   "est_connu_de",   "collegue":    "est_connu_de",
        "voisin":     "est_connu_de",   "voisine":     "est_connu_de",
        "connaissance":"est_connu_de",
        # Hiérarchique
        "est un":     "est_un",         "est une":     "est_un",
        "fait partie":"fait_partie_de", "appartient":  "fait_partie_de",
        "contient":   "contient",       "comprend":    "contient",
        # Attributif
        "caractérisé":"a_pour_caracteristique",
        "a pour":     "a_pour_caracteristique",
        # Spatial
        "habite":     "est_situe_a",    "vit":         "est_situe_a",
        "situé":      "est_situe_a",    "situe":       "est_situe_a",
        "localisé":   "est_situe_a",    "trouve":      "est_situe_a",
        # Temporel
        "précède":    "precede",        "precede":     "precede",
        "suit":       "suit",           "avant":       "precede",
        "après":      "suit",           "apres":       "suit",
        # Littéraire
        "écrit":      "a_ecrit",        "ecrit":       "a_ecrit",
        "écrit par":  "est_ecrit_par",  "auteur":      "a_ecrit",
    }

    # Sub_intents → stratégie d'analyse prioritaire
    SUBINTENT_STRATEGY: Dict[str, List[str]] = {
        "presentation_personne": ["attributes", "ner", "relations"],
        "attribut_personne":     ["attributes", "ner", "properties"],
        "localisation_personne": ["attributes", "ner", "spatial"],
        "date_evenement":        ["attributes", "ner", "temporal"],
        "relation_personne":     ["attributes", "ner", "relations"],
        "statement":             ["ner", "relations", "properties"],
        # Extensible — ajouter des sub_intents sans modifier le code
    }

    def __init__(self):
        self._visitors: List[IntentVisitor] = []

    def register(self, visitor: IntentVisitor) -> "IntentAnalyzer":
        """Enregistre un visiteur. Chaînable."""
        self._visitors.append(visitor)
        return self

    def analyze(self, intent) -> AnalyseIntent:
        """
        Analyse l'intent et dispatch sur tous les visiteurs.
        Retourne l'AnalyseIntent pour inspection si nécessaire.
        """
        source = self._make_source(intent)
        analyse = AnalyseIntent(source=source)

        sub = intent.semantic.get("sub_intent", "statement")
        strategies = self.SUBINTENT_STRATEGY.get(
            sub, ["ner", "relations", "properties"]
        )

        # Exécuter les analyses selon la stratégie
        for strategy in strategies:
            if strategy == "attributes":
                self._analyze_attributes(intent, analyse)
            elif strategy == "ner":
                self._analyze_ner(intent, analyse)
            elif strategy == "relations":
                self._analyze_relations(intent, analyse)
            elif strategy == "properties":
                self._analyze_properties(intent, analyse)
            elif strategy == "spatial":
                self._analyze_spatial(intent, analyse)
            elif strategy == "temporal":
                self._analyze_temporal(intent, analyse)

        # Dédupliquer
        self._deduplicate(analyse)

        # Dispatcher sur les visiteurs
        for visitor in self._visitors:
            visitor.begin(intent, analyse)
            for e in analyse.entites:
                visitor.visit_entite(e, source)
            for r in analyse.relations:
                visitor.visit_relation(r, source)
            for p in analyse.proprietes:
                visitor.visit_propriete(p, source)
            visitor.end(intent, analyse)

        return analyse

    # ----------------------------------------------------------
    # Analyses
    # ----------------------------------------------------------

    def _analyze_attributes(self, intent, analyse: AnalyseIntent):
        """Extrait les entités et propriétés depuis intent.attributes."""
        attrs = intent.attributes

        # Entité principale : personne, concept, objet, lieu
        for slot in ("personne", "concept", "objet", "lieu", "sujet"):
            attr = attrs.get(slot)
            if not attr:
                continue
            val = str(attr.value).strip()
            if not val or len(val) < 2:
                continue

            nature_map = {
                "personne": ("personne",  "social"),
                "lieu":     ("lieu",      "permanent"),
                "concept":  ("categorie", "permanent"),
                "objet":    ("objet",     "episodique"),
                "sujet":    ("categorie", "episodique"),
            }
            nature_str, mem_str = nature_map.get(slot, ("categorie", "episodique"))

            analyse.entites.append(EntiteDetectee(
                nom=val,
                nature=nature_str,
                mem_type=mem_str,
                source_ner=slot,
                confiance=float(attr.source.confidence
                                if hasattr(attr, "source") else 0.8)
            ))

        # Relation textuelle
        rel_attr = attrs.get("relation")
        if rel_attr:
            rel_str = str(rel_attr.value).lower().strip()
            rel_type = self._map_relation(rel_str)
            # La relation sera construite dans _analyze_relations
            # On stocke la valeur brute pour référence
            analyse.proprietes.append(ProprieteDetectee(
                concept="_relation_brute",
                nom="type",
                valeur=rel_str,
                type_val="relation_brute",
                confiance=0.7
            ))

        # Attribut / description
        for slot in ("attribut", "description", "valeur"):
            attr = attrs.get(slot)
            if not attr:
                continue
            # Associer à la première entité trouvée
            if analyse.entites:
                analyse.proprietes.append(ProprieteDetectee(
                    concept=analyse.entites[0].nom,
                    nom=slot,
                    valeur=str(attr.value),
                    type_val="texte",
                    confiance=0.75
                ))

    def _analyze_ner(self, intent, analyse: AnalyseIntent):
        """Extrait les entités depuis les annotations NER brutes."""
        ner_attr = intent.attributes.get("_ner")
        if not ner_attr or not ner_attr.value:
            return

        existing_noms = {e.nom.lower() for e in analyse.entites}

        for ent in ner_attr.value:
            label = ent.get("label", "")
            text  = ent.get("text", "").strip()
            if not text or len(text) < 2:
                continue
            if text.lower() in existing_noms:
                continue  # déjà ajouté via attributes

            nature_str, mem_str = self.NER_NATURE_MAP.get(
                label, ("categorie", "episodique")
            )
            analyse.entites.append(EntiteDetectee(
                nom=text,
                nature=nature_str,
                mem_type=mem_str,
                source_ner=label,
                confiance=0.7
            ))
            existing_noms.add(text.lower())

    def _analyze_relations(self, intent, analyse: AnalyseIntent):
        """
        Infère les relations entre entités.

        Sources :
        1. Relation textuelle extraite dans _analyze_attributes
        2. Sub_intent comme indicateur de relation
        3. Paires d'entités + verbe du texte brut
        """
        entites = [e for e in analyse.entites if e.nature != "relation_brute"]
        if len(entites) < 1:
            return

        # Récupérer la relation brute si disponible
        rel_brute = next(
            (p.valeur for p in analyse.proprietes
             if p.concept == "_relation_brute"),
            None
        )

        sub = intent.semantic.get("sub_intent", "")

        # Relation depuis le sub_intent
        sub_relation_map = {
            "presentation_personne": "est_connu_de",
            "localisation_personne": "est_situe_a",
            "relation_personne":     "est_connu_de",
        }

        if rel_brute:
            rel_type = self._map_relation(rel_brute)
            if rel_type and len(entites) >= 1:
                analyse.relations.append(RelationDetectee(
                    sujet=entites[0].nom,
                    type=rel_type,
                    cible="locuteur",
                    confiance=0.8
                ))
        elif sub in sub_relation_map and entites:
            rel_type = sub_relation_map[sub]
            analyse.relations.append(RelationDetectee(
                sujet=entites[0].nom,
                type=rel_type,
                cible="locuteur",
                confiance=0.7
            ))

        # Relation entre paires d'entités du même intent
        # Ex : "Paul et Marie sont amis" → paul EST_AMI_DE marie
        if len(entites) >= 2:
            text_attr = intent.attributes.get("text")
            if text_attr:
                text = str(text_attr.value).lower()
                for rel_str, rel_type_str in self.RELATION_MAP.items():
                    if rel_str in text:
                        # Relation entre la première et la deuxième entité
                        analyse.relations.append(RelationDetectee(
                            sujet=entites[0].nom,
                            type=rel_type_str,
                            cible=entites[1].nom,
                            confiance=0.65
                        ))
                        break

    def _analyze_properties(self, intent, analyse: AnalyseIntent):
        """Extrait les propriétés génériques portées par l'intent."""
        if not analyse.entites:
            return

        entite_principale = analyse.entites[0].nom
        attrs = intent.attributes

        # Tout attribut non déjà traité devient une propriété
        traites = {"personne", "concept", "objet", "lieu", "sujet",
                   "relation", "attribut", "text", "_ner",
                   "reference_temporelle", "heure", "date"}

        for nom, attr in attrs.items():
            if nom in traites:
                continue
            valeur = attr.value if hasattr(attr, "value") else attr
            if valeur is None:
                continue
            analyse.proprietes.append(ProprieteDetectee(
                concept=entite_principale,
                nom=nom,
                valeur=str(valeur),
                type_val="texte",
                confiance=0.7
            ))

    def _analyze_spatial(self, intent, analyse: AnalyseIntent):
        """Analyse spécialisée pour les relations spatiales."""
        lieu_attr = (intent.attributes.get("lieu")
                     or intent.attributes.get("location"))
        if not lieu_attr:
            # Chercher dans les entités NER de type LOC
            for e in analyse.entites:
                if e.source_ner in ("LOC", "GPE", "FAC"):
                    # C'est déjà dans analyse.entites — ajouter la relation
                    if analyse.entites and analyse.entites[0].nom != e.nom:
                        analyse.relations.append(RelationDetectee(
                            sujet=analyse.entites[0].nom,
                            type="est_situe_a",
                            cible=e.nom,
                            confiance=0.75
                        ))
            return

        lieu = str(lieu_attr.value).strip()
        if not lieu:
            return

        # Ajouter le lieu comme entité
        analyse.entites.append(EntiteDetectee(
            nom=lieu, nature="lieu", mem_type="permanent",
            source_ner="LOC", confiance=0.8
        ))

        # Créer la relation spatiale avec la première entité
        if analyse.entites and analyse.entites[0].nom != lieu:
            analyse.relations.append(RelationDetectee(
                sujet=analyse.entites[0].nom,
                type="est_situe_a",
                cible=lieu,
                confiance=0.8
            ))

    def _analyze_temporal(self, intent, analyse: AnalyseIntent):
        """Analyse spécialisée pour les informations temporelles."""
        date_attr  = (intent.attributes.get("reference_temporelle")
                      or intent.attributes.get("date"))
        heure_attr = intent.attributes.get("heure")
        text_attr  = intent.attributes.get("text")

        # Créer un nœud événement
        evt_nom = str(text_attr.value)[:60] if text_attr else f"evt_{uuid.uuid4().hex[:6]}"

        analyse.entites.append(EntiteDetectee(
            nom=evt_nom, nature="action", mem_type="episodique",
            source_ner="EVENT", confiance=0.75
        ))

        if date_attr:
            analyse.proprietes.append(ProprieteDetectee(
                concept=evt_nom,
                nom="date_reference",
                valeur=str(date_attr.value),
                type_val="texte",
                confiance=0.8
            ))
        if heure_attr:
            analyse.proprietes.append(ProprieteDetectee(
                concept=evt_nom,
                nom="heure",
                valeur=str(heure_attr.value),
                type_val="texte",
                confiance=0.8
            ))

    # ----------------------------------------------------------
    # Helpers
    # ----------------------------------------------------------

    def _map_relation(self, rel_str: str) -> Optional[str]:
        """Mappe une chaîne vers un type de relation."""
        if rel_str in self.RELATION_MAP:
            return self.RELATION_MAP[rel_str]
        for key, val in self.RELATION_MAP.items():
            if key in rel_str:
                return val
        return None

    def _deduplicate(self, analyse: AnalyseIntent):
        """Supprime les doublons d'entités et de relations."""
        seen_e = set()
        unique_e = []
        for e in analyse.entites:
            key = (e.nom.lower(), e.nature)
            if key not in seen_e and e.concept if hasattr(e, 'concept') else True:
                seen_e.add(key)
                unique_e.append(e)
        analyse.entites = [e for e in analyse.entites
                           if e.nom.lower() + e.nature not in
                           (x.nom.lower() + x.nature for x in unique_e[:unique_e.index(e)])]

        # Dédupliquer relations
        seen_r = set()
        unique_r = []
        for r in analyse.relations:
            key = (r.sujet.lower(), str(r.type), r.cible.lower())
            if key not in seen_r:
                seen_r.add(key)
                unique_r.append(r)
        analyse.relations = unique_r

        # Nettoyer propriétés internes
        analyse.proprietes = [
            p for p in analyse.proprietes
            if p.concept != "_relation_brute"
        ]

    @staticmethod
    def _make_source(intent) -> Any:
        """Construit un SourceInfo depuis l'intent."""
        # SourceInfo et SourceWeight sont dans cognition_core v10
        # On passe par une référence dynamique pour éviter l'import circulaire
        return {
            "speaker":    intent.speaker,
            "confidence": intent.semantic.get("confidence", 0.8),
            "timestamp":  time.time()
        }


# ============================================================
# VISITEURS CONCRETS
# ============================================================

class GraphStorageVisitor(IntentVisitor):
    """
    Visiteur principal — écrit dans le KnowledgeGraph.
    Crée ou enrichit les nœuds, relations et propriétés.
    """

    # Mapping string → ConceptNature (pour éviter l'import au niveau module)
    _NATURE_MAP = {
        "personne":   "PERSONNE",
        "lieu":       "LIEU",
        "objet":      "OBJET",
        "action":     "ACTION",
        "categorie":  "CATEGORIE",
        "instance":   "INSTANCE",
        "intervalle": "INTERVALLE",
        "point":      "POINT",
        "emotion":    "EMOTION",
        "concept_scientifique": "CONCEPT_SCIENTIFIQUE",
        "oeuvre_litteraire":    "OEUVRE_LITTERAIRE",
    }

    _MEM_MAP = {
        "permanent":  "PERMANENT",
        "episodique": "EPISODIQUE",
        "social":     "SOCIAL",
        "litteraire": "LITTERAIRE_ROMAN",
        "narrative":  "NARRATIVE",
    }

    def __init__(self, graph, SourceInfo_cls, SourceWeight_cls,
                 ConceptNature_cls, MemoryType_cls, RelationType_cls):
        self.graph          = graph
        self.SourceInfo     = SourceInfo_cls
        self.SourceWeight   = SourceWeight_cls
        self.ConceptNature  = ConceptNature_cls
        self.MemoryType     = MemoryType_cls
        self.RelationType   = RelationType_cls
        self._created: List[str] = []
        self._updated: List[str] = []

    def begin(self, intent, analyse):
        self._created.clear()
        self._updated.clear()

    def visit_entite(self, e: EntiteDetectee, source) -> None:
        """Crée ou récupère le concept dans le graphe."""
        try:
            nature  = self.ConceptNature[
                self._NATURE_MAP.get(e.nature, "CATEGORIE")
            ]
            mem     = self.MemoryType[
                self._MEM_MAP.get(e.mem_type, "EPISODIQUE")
            ]
            src = self.SourceInfo(
                type=self.SourceWeight.REPORTED,
                confidence=e.confiance
            )
            concept = self.graph.get_or_create(e.nom, nature, mem, src)
            if concept:
                self._created.append(e.nom)
        except Exception as ex:
            logger.debug(f"GraphStorageVisitor.visit_entite({e.nom}) : {ex}")

    def visit_relation(self, r: RelationDetectee, source) -> None:
        """Ajoute la relation dans le graphe."""
        try:
            # Résoudre le type de relation
            rel_type = None
            for rt in self.RelationType:
                if rt.value == r.type:
                    rel_type = rt
                    break
            if rel_type is None:
                return

            src = self.SourceInfo(
                type=self.SourceWeight.REPORTED,
                confidence=r.confiance
            )
            self.graph.add_relation(r.sujet, rel_type, r.cible, src)
            logger.debug(f"Relation : {r.sujet} → {r.type} → {r.cible}")
        except Exception as ex:
            logger.debug(f"GraphStorageVisitor.visit_relation : {ex}")

    def visit_propriete(self, p: ProprieteDetectee, source) -> None:
        """Ajoute la propriété sur le concept dans le graphe."""
        try:
            concept = self.graph.get(p.concept)
            if not concept:
                return
            src = self.SourceInfo(
                type=self.SourceWeight.REPORTED,
                confidence=p.confiance
            )
            concept.add_propriete(p.nom, p.valeur, p.type_val, src)
            self._updated.append(p.concept)
        except Exception as ex:
            logger.debug(f"GraphStorageVisitor.visit_propriete : {ex}")

    def end(self, intent, analyse):
        if self._created or self._updated:
            logger.info(
                f"Graphe enrichi — créés: {self._created}, "
                f"enrichis: {list(set(self._updated))}"
            )


class ContextUpdateVisitor(IntentVisitor):
    """
    Visiteur léger — met à jour le ContextFrame avec les
    entités découvertes (sujets actifs, lieu courant...).
    """

    def __init__(self, context_frame):
        self.ctx = context_frame

    def visit_entite(self, e: EntiteDetectee, source) -> None:
        if not self.ctx:
            return
        if e.nature == "personne":
            subjects = list(getattr(self.ctx, "subjects", []))
            if e.nom not in subjects:
                subjects.append(e.nom)
            try:
                self.ctx.update(subjects=subjects[-10:])
            except Exception:
                pass
        elif e.nature == "lieu":
            try:
                self.ctx.update(where=e.nom)
            except Exception:
                pass

    def visit_relation(self, r: RelationDetectee, source) -> None:
        pass

    def visit_propriete(self, p: ProprieteDetectee, source) -> None:
        pass


class NarrativeVisitor(IntentVisitor):
    """
    Visiteur — décide si l'information est narrativement significative
    et la pousse dans la narrative_queue si oui.

    Critères de significativité :
      - Nouvelle entité de type PERSONNE ou ACTION
      - Relation entre personnes
      - Événement horodaté
    """

    def __init__(self, narrative_store, intent_ref):
        self.store      = narrative_store
        self.intent_ref = intent_ref
        self._significant = False

    def begin(self, intent, analyse):
        self._significant = False

    def visit_entite(self, e: EntiteDetectee, source) -> None:
        if e.nature in ("personne", "action"):
            self._significant = True

    def visit_relation(self, r: RelationDetectee, source) -> None:
        self._significant = True

    def visit_propriete(self, p: ProprieteDetectee, source) -> None:
        if p.nom in ("date_reference", "heure"):
            self._significant = True

    def end(self, intent, analyse):
        if self._significant and self.store:
            self.store.push(self.intent_ref, source="cognition")


# ============================================================
# ANCRAGE LEXICAL — APPRENTISSAGE PERSONNEL DES QUALIFICATIFS
# ============================================================

@dataclass
class ObservationQualificatif:
    """
    Une observation contextualisée d'un qualificatif.
    Stocke le mot, le concept qualifié, et l'état affectif du moment.
    """
    mot:          str
    concept_cible: str            # "sarah", "rex", "jazz"...
    affect_valence:  float = 0.0  # VAD au moment de l'observation
    affect_arousal:  float = 0.3
    affect_dominance: float = 0.6
    timestamp:    float = field(default_factory=time.time)
    source:       str = "conversation"


@dataclass
class AnchorQualificatif:
    """
    Ancrage d'un qualificatif pour une entité donnée.

    Accumule les observations contextuelles et calcule une projection
    émergente sur les dimensions de résonance — propre à cette entité,
    non universelle.

    confiance croît avec le nombre d'observations et leur dispersion
    temporelle (10 observations en 1 jour < 10 observations sur 6 mois).
    """
    mot:          str
    observations: List[ObservationQualificatif] = field(default_factory=list)
    projection:   Dict[str, float] = field(default_factory=dict)
    confiance:    float = 0.0

    def add_observation(self, obs: ObservationQualificatif):
        self.observations.append(obs)
        self._recalculate()

    def _recalculate(self):
        """
        Recalcule la projection et la confiance depuis les observations.

        Projection : corrélation entre l'affect au moment de l'observation
        et les dimensions de résonance.

        Logique :
          - valence positive forte → le mot est associé à chaleur, partage
          - arousal élevé          → le mot est associé à intensite, rythme
          - dominance élevée       → le mot est associé à ordre, ancrage
          - valence négative        → dimensions négatives

        La dispersion temporelle pondère la confiance :
        observations distillées dans le temps = ancrage plus robuste.
        """
        n = len(self.observations)
        if n == 0:
            return

        # Moyennes des états affectifs
        moy_v = sum(o.affect_valence   for o in self.observations) / n
        moy_a = sum(o.affect_arousal   for o in self.observations) / n
        moy_d = sum(o.affect_dominance for o in self.observations) / n

        # Projection sur les 10 dimensions depuis les axes VAD
        # Chaque dimension est une combinaison linéaire des axes
        # Ces coefficients sont la sémantique de l'architecture VAD
        self.projection = {
            "complexite":      round(0.4 * moy_v + 0.3 * moy_a + 0.3 * moy_d, 3),
            "imprevisibilite": round(0.2 * moy_v + 0.6 * moy_a - 0.2 * moy_d, 3),
            "intensite":       round(0.3 * moy_v + 0.5 * moy_a + 0.2 * moy_d, 3),
            "sensorialite":    round(0.4 * moy_v + 0.4 * moy_a + 0.2 * moy_d, 3),
            "partage":         round(0.6 * moy_v + 0.1 * moy_a + 0.3 * moy_d, 3),
            "rythme":          round(0.1 * moy_v + 0.7 * moy_a + 0.2 * moy_d, 3),
            "ordre":           round(0.1 * moy_v - 0.2 * moy_a + 0.7 * moy_d, 3),
            "chaleur":         round(0.7 * moy_v + 0.1 * moy_a + 0.2 * moy_d, 3),
            "ancrage":         round(0.2 * moy_v - 0.1 * moy_a + 0.7 * moy_d, 3),
            "familiarite":     round(0.5 * moy_v - 0.1 * moy_a + 0.4 * moy_d, 3),
        }

        # Confiance = f(nombre d'observations, dispersion temporelle)
        self.confiance = self._compute_confiance()

    def _compute_confiance(self) -> float:
        """
        Confiance croît avec le nombre d'observations ET leur dispersion
        temporelle. 10 observations groupées < 10 observations étalées.
        """
        n = len(self.observations)
        if n < 2:
            return min(0.2, n * 0.1)

        # Facteur quantité : log pour éviter la saturation rapide
        import math
        facteur_n = min(1.0, math.log(n + 1) / math.log(20))

        # Facteur dispersion : écart-type des timestamps normalisé
        timestamps = [o.timestamp for o in self.observations]
        duree_totale = max(timestamps) - min(timestamps)
        # 30 jours = dispersion maximale (saturation)
        facteur_disp = min(1.0, duree_totale / (30 * 86400))

        # Pondération : 60% quantité, 40% dispersion
        return round(0.6 * facteur_n + 0.4 * facteur_disp, 3)


class AncrageLexical:
    """
    Gestionnaire d'ancrage lexical personnel.

    Accumule les observations contextuelles des qualificatifs
    et calcule leurs projections émergentes sur les dimensions
    de résonance — propres à cette entité, non universelles.

    Persiste dans le graphe sous forme de propriétés sur les
    concepts-qualificatifs.

    Usage :
        ancrage = AncrageLexical(graph)
        ancrage.observer("brillant", "sarah",
                          affect=AffectiveState(0.7, 0.6, 0.7))
        proj = ancrage.projection("brillant")
        # → {"complexite": 0.68, "intensite": 0.62, ...}
    """

    def __init__(self, graph):
        self.graph = graph
        self._anchors: Dict[str, AnchorQualificatif] = {}
        self._lock = threading.RLock()

    def observer(self, mot: str, concept_cible: str,
                 affect_valence: float = 0.0,
                 affect_arousal: float = 0.3,
                 affect_dominance: float = 0.6,
                 source: str = "conversation"):
        """
        Enregistre une observation contextuelle d'un qualificatif.

        mot            : le qualificatif ("brillant", "froid", "drôle"...)
        concept_cible  : le concept qualifié ("sarah", "jazz", "lundi"...)
        affect_*       : état affectif VAD au moment de l'observation
        """
        mot_lower = mot.lower().strip()
        if not mot_lower:
            return

        obs = ObservationQualificatif(
            mot=mot_lower,
            concept_cible=concept_cible,
            affect_valence=affect_valence,
            affect_arousal=affect_arousal,
            affect_dominance=affect_dominance,
            source=source
        )

        with self._lock:
            if mot_lower not in self._anchors:
                self._anchors[mot_lower] = AnchorQualificatif(mot=mot_lower)
            anchor = self._anchors[mot_lower]
            anchor.add_observation(obs)

        # Persister la projection dans le graphe si confiance suffisante
        if anchor.confiance >= 0.2:
            self._persist_projection(mot_lower, anchor)

        logger.debug(
            f"AncrageLexical : '{mot_lower}' sur '{concept_cible}' "
            f"— {len(anchor.observations)} obs, confiance={anchor.confiance:.2f}"
        )

    def projection(self, mot: str) -> Dict[str, float]:
        """
        Retourne la projection courante d'un qualificatif
        sur les dimensions de résonance.
        Retourne {} si le mot n'a pas encore été observé.
        """
        mot_lower = mot.lower().strip()
        with self._lock:
            anchor = self._anchors.get(mot_lower)
            if anchor:
                return dict(anchor.projection)

        # Chercher dans le graphe (observations d'une session précédente)
        concept = self.graph.get(f"__qualif_{mot_lower}")
        if concept:
            proj = concept.proprietes.get("projection_resonance")
            if proj:
                return json.loads(proj.valeur) if isinstance(proj.valeur, str) \
                       else proj.valeur
        return {}

    def confiance(self, mot: str) -> float:
        """Retourne la confiance courante pour un qualificatif."""
        mot_lower = mot.lower().strip()
        with self._lock:
            anchor = self._anchors.get(mot_lower)
            return anchor.confiance if anchor else 0.0

    def mots_ancres(self) -> List[str]:
        """Liste des qualificatifs avec une projection calculée."""
        with self._lock:
            return [m for m, a in self._anchors.items()
                    if a.confiance >= 0.2]

    def _persist_projection(self, mot: str, anchor: AnchorQualificatif):
        """
        Persiste la projection dans le graphe sous un nœud dédié.
        Nœud nommé __qualif_{mot} pour éviter les collisions.
        """
        try:
            from dataclasses import asdict as _asdict
            # Nœud interne pour stocker la projection
            nœud_nom = f"__qualif_{mot}"
            # On ne peut pas importer SourceInfo ici directement
            # → on passe par get_or_create avec des classes stockées
            # si le graphe les a (set lors de l'init de CognitionCore)
            concept = self.graph.get(nœud_nom)
            if concept:
                # Mettre à jour la projection
                prop = concept.proprietes.get("projection_resonance")
                if prop:
                    prop.valeur = json.dumps(anchor.projection)
                    prop.confiance = anchor.confiance
        except Exception as e:
            logger.debug(f"AncrageLexical persist : {e}")


class AncrageLexicalVisitor(IntentVisitor):
    """
    Visiteur — détecte les qualificatifs dans les propriétés
    et les enregistre dans l'AncrageLexical avec le contexte
    affectif courant.

    C'est ici que le langage acquiert sa signification personnelle.
    "Brillant" n'a pas de valeur universelle — il prend sens
    à travers les observations de cette entité, dans ses contextes.
    """

    # Types de propriétés qui sont des qualificatifs
    QUALIFICATIF_TYPES = {
        "adjectif", "description", "attribut", "qualite",
        "caracteristique", "texte"
    }

    # Mots à ignorer (déterminants, auxiliaires, etc.)
    STOP_QUALIFICATIFS = {
        "un", "une", "le", "la", "les", "des", "de", "du",
        "est", "sont", "être", "avoir", "très", "plus", "moins",
        "assez", "peu", "trop", "bien", "mal", "vrai", "faux"
    }

    def __init__(self, ancrage_lexical: AncrageLexical,
                 affect_valence: float = 0.0,
                 affect_arousal: float = 0.3,
                 affect_dominance: float = 0.6):
        self.ancrage          = ancrage_lexical
        self.affect_valence   = affect_valence
        self.affect_arousal   = affect_arousal
        self.affect_dominance = affect_dominance
        self._concept_courant: Optional[str] = None

    def set_affect(self, valence: float, arousal: float, dominance: float):
        """Met à jour l'état affectif avant la visite."""
        self.affect_valence   = valence
        self.affect_arousal   = arousal
        self.affect_dominance = dominance

    def begin(self, intent, analyse):
        self._concept_courant = None

    def visit_entite(self, e: EntiteDetectee, source) -> None:
        """Mémorise la première entité comme concept cible courant."""
        if self._concept_courant is None:
            self._concept_courant = e.nom

    def visit_relation(self, r: RelationDetectee, source) -> None:
        pass

    def visit_propriete(self, p: ProprieteDetectee, source) -> None:
        """
        Si la propriété est un qualificatif, l'enregistre dans
        l'AncrageLexical avec le contexte affectif courant.
        """
        if p.type_val not in self.QUALIFICATIF_TYPES:
            return

        concept_cible = p.concept or self._concept_courant or "inconnu"
        valeur = str(p.valeur).strip().lower()

        if not valeur or len(valeur) < 2:
            return

        # Extraire les mots qualificatifs de la valeur
        mots = re.findall(r'\b[a-zàáâãäåæçèéêëìíîïðñòóôõöùúûüýþÿœ-]{3,}\b',
                          valeur)

        for mot in mots:
            if mot in self.STOP_QUALIFICATIFS:
                continue
            self.ancrage.observer(
                mot=mot,
                concept_cible=concept_cible,
                affect_valence=self.affect_valence,
                affect_arousal=self.affect_arousal,
                affect_dominance=self.affect_dominance,
                source="conversation"
            )

    def end(self, intent, analyse):
        pass

# ============================================================
# ADAPTATEUR ParseResult → StructuredIntent
# ============================================================

class ParseResultAdapter:
    """
    Convertit un ParseResult (sorti de IntentParser)
    en StructuredIntent (consommé par CognitionCore._cognize).
    """

    @staticmethod
    def to_intent(result: ParseResult,
                  conversation_id: str,
                  speaker: str,
                  text: str,
                  SourceInfo, SourceWeight, Attribute,
                  StructuredIntent) -> "StructuredIntent":
        """
        result          : ParseResult de nlp_parser
        conversation_id : identifiant de la conversation courante
        speaker         : identifiant du locuteur
        text            : texte brut original (conservé en attribut)
        """
        intent_id = f"intent_{uuid.uuid4().hex[:8]}"
        source = SourceInfo(type=SourceWeight.OBSERVATION,
                            confidence=result.confidence)

        # Attributs de base
        attributes = {
            "text": Attribute(
                type="string",
                value=text,
                source=source
            )
        }

        # Entités extraites → attributs typés
        for slot_name, slot_val in result.entities.items():
            if slot_name.endswith("_resolved"):
                continue  # métadonnée interne

            # Typage automatique
            if isinstance(slot_val, dict):
                attr_type = "object"
            elif isinstance(slot_val, (int, float)):
                attr_type = "number"
            else:
                attr_type = "string"

            attributes[slot_name] = Attribute(
                type=attr_type,
                value=slot_val,
                source=source
            )

        # Entités NER brutes → attribut séparé pour traçabilité
        if result.raw_entities:
            attributes["_ner"] = Attribute(
                type="list",
                value=result.raw_entities,
                source=source
            )

        # Sémantique
        semantic = {
            "intent": result.intent,
            "sub_intent": result.sub_intent,
            "type": result.intent,      # compatibilité v10
            "confidence": result.confidence,
            "sentence_type": result.sentence_type,
            "negated": result.negated,
            "parser_version": "spacy_v1"
        }

        # Pattern source
        if result.matched_pattern_id:
            semantic["matched_pattern"] = result.matched_pattern_id

        return StructuredIntent(
            id=intent_id,
            timestamp=time.time(),
            conversation_id=conversation_id,
            speaker=speaker,
            semantic=semantic,
            attributes=attributes
        )


# ============================================================
# COGNITION CORE v11
# ============================================================

class CognitionCore:
    """
    Cœur cognitif v11.

    Remplace :
    - _text_to_intent  → IntentParser (spaCy + patterns JSON)
    - SentenceBuilder  → TemplateBuilder (templates JSON + FrenchMorphology)

    Interface publique identique à v10.
    """

    def __init__(self, data_path: Path, gem_path: Path,
                 patterns_dir: Path = Path("./patterns"),
                 templates_dir: Path = Path("./templates"),
                 narrative_dir: Path = Path("./narrative")):
        """
        data_path     : répertoire de données persistantes (graphe, index)
        gem_path      : fichier gem.json
        patterns_dir  : répertoire des patterns NLP par domaine
        templates_dir : répertoire des templates de génération par domaine
        narrative_dir : répertoire de la mémoire narrative
        """
        self.data_path = Path(data_path)
        self.data_path.mkdir(parents=True, exist_ok=True)

        # --- Gem ---
        logger.info(f"📖 Chargement du Gem depuis {gem_path}")
        self.gem = Gem.from_file(gem_path)

        # --- Graphe de connaissances ---
        self.graph = KnowledgeGraph(self.data_path / "graph")

        # --- Morphologie française ---
        self.morpho = FrenchMorphology()

        # --- Parseur NLP ---
        logger.info(f"🔬 Initialisation IntentParser (patterns: {patterns_dir})")
        self._parser: Optional[IntentParser] = None
        self._patterns_dir  = Path(patterns_dir)
        self._templates_dir = Path(templates_dir)
        self._init_parser()

        # --- Générateur de texte ---
        self.builder = GrammarBuilder(
            gem=self.gem,
            morpho=self.morpho,
            bases_dir=Path("./bases")
        )

        # --- Contexte ---
        self.current_conversation: Optional[ContextFrame] = None
        self.system_context = SystemContext()

        # --- Queue d'actions sortante (publique) ---
        # Intents actionnables émis ou reçus → consommés par le planificateur externe
        self.action_queue: queue.Queue = queue.Queue()

        # Ensemble des sub_intents actionnables — chargé depuis patterns/actions.json
        self._actionable_intents: Dict[str, Set[str]] = {
            "entrants": set(),
            "sortants": set()
        }
        self._load_actionable_intents(self._patterns_dir / "actions.json")

        # --- Mémoire narrative (entrée externe, lecture isolée) ---
        self.narrative_store = NarrativeStore(
            narrative_dir=Path(narrative_dir),
            gem_id=self.gem.identifiant
        )

        # --- Ancrage lexical personnel ---
        # Accumule les observations contextuelles des qualificatifs
        # et calcule leurs projections émergentes sur les dimensions
        # de résonance — propres à cette entité, non universelles.
        self.ancrage_lexical = AncrageLexical(self.graph)

        # --- Dérive affective (VAD dynamique sans SomaCore) ---
        self.affect_drift = AffectiveDrift(
            valence   = 0.0,
            arousal   = 0.3,
            dominance = 0.6,
            inertie   = getattr(self.gem, "inertie_affective", 0.85)
        )

        # --- Résumé conversationnel ---
        self.conversation_summary = ConversationSummary()

        # --- Intent de curiosité en attente (produit par _cognize) ---
        # La couche supérieure peut le lire via core.pending_curiosity
        self._pending_curiosity: Optional["StructuredIntent"] = None

        # --- Threads ---
        self._running = False
        self._cooling_thread = None
        self._nightly_thread = None

        logger.info(f"✅ CognitionCore v{__version__} — Gem: {self.gem.nom}")

    # ----------------------------------------------------------
    # INITIALISATION DES NOUVEAUX COMPOSANTS
    # ----------------------------------------------------------

    def _init_parser(self):
        """Initialise l'IntentParser avec tous les domaines disponibles."""
        try:
            self._parser = IntentParser(
                patterns_dir=self._patterns_dir,
                graph=self.graph
            )
            # Activer le LLM fallback seulement si l'option globale est True
            if USE_LLM_FALLBACK:
                llm_config = getattr(self.gem, "llm_fallback", None)
                if llm_config is None:
                    llm_config = {
                        "provider":  "ollama",
                        "model":     "mistral",
                        "threshold": 0.5,
                        "timeout":   5
                    }
                self._parser.enable_llm_fallback(
                    provider  = llm_config.get("provider",  "ollama"),
                    model     = llm_config.get("model",     "mistral"),
                    threshold = llm_config.get("threshold", 0.5),
                    timeout   = llm_config.get("timeout",   5)
                )
            else:
                logger.info("LLM fallback désactivé (USE_LLM_FALLBACK=False)")

        except RuntimeError as e:
            logger.error(f"⚠️  IntentParser non disponible : {e}")
            logger.warning("   → Fallback sur le parseur basique")
            self._parser = None

    def _load_actionable_intents(self, actions_path: Path):
        """
        Charge depuis patterns/actions.json les sub_intents actionnables.
        Si le fichier est absent, les ensembles restent vides.
        """
        if not actions_path.exists():
            logger.warning(f"patterns/actions.json introuvable — action_queue désactivée")
            return
        try:
            with open(actions_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._actionable_intents["entrants"] = set(
                data.get("actionable_sub_intents", {}).get("entrants", [])
            )
            self._actionable_intents["sortants"] = set(
                data.get("actionable_sub_intents", {}).get("sortants", [])
            )
            logger.info(
                f"Actions chargées — entrants: {len(self._actionable_intents['entrants'])}, "
                f"sortants: {len(self._actionable_intents['sortants'])}"
            )
        except Exception as e:
            logger.error(f"Erreur chargement actions.json : {e}")

    def load_knowledge_base(self, name: str, filepath: Path):
        """
        Charge une base de connaissances ET le domaine de patterns/templates
        correspondant si disponible.
        """
        # Chargement graphe (identique v10)
        logger.info(f"📚 Chargement base '{name}' depuis {filepath}")
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        source = SourceInfo(type=SourceWeight.EDUCATIVE)

        for concept_data in data.get("concepts", []):
            concept = Concept(
                id=concept_data.get("id", f"kb_{uuid.uuid4().hex[:8]}"),
                nom=concept_data["nom"],
                nature=ConceptNature(concept_data["nature"]),
                memoire_type=MemoryType(concept_data.get("memoire_type", "permanent")),
                aliases=set(concept_data.get("aliases", []))
            )
            self.graph.add_concept(concept)

            for rel in concept_data.get("relations", []):
                self.graph.add_relation(
                    concept.id,
                    RelationType(rel["type"]),
                    rel["cible"],
                    source
                )

            for prop, val in concept_data.get("proprietes", {}).items():
                concept.add_propriete(
                    prop, val["valeur"], val.get("type", "texte"), source
                )

        count = len(data.get("concepts", []))
        logger.info(f"  ✓ {count} concepts chargés")

        # Charger le domaine de patterns correspondant si disponible
        if self._parser:
            pattern_file = self._patterns_dir / f"{name}.json"
            if pattern_file.exists():
                self._parser.load_domain(name)

        # Charger le domaine de templates correspondant si disponible
        template_file = self._templates_dir / f"{name}.json"
        if template_file.exists():
            self.builder.load_domain(name)

    # ----------------------------------------------------------
    # THREADS DE MAINTENANCE (inchangés v10)
    # ----------------------------------------------------------

    def start(self):
        self._running = True
        self._cooling_thread = threading.Thread(
            target=self._cooling_loop, name="cooling", daemon=True
        )
        self._cooling_thread.start()
        self._nightly_thread = threading.Thread(
            target=self._nightly_loop, name="nightly", daemon=True
        )
        self._nightly_thread.start()
        self.narrative_store.start()
        logger.info("✅ CognitionCore démarré")

    def stop(self):
        self._running = False
        if self._cooling_thread:
            self._cooling_thread.join(timeout=5)
        if self._nightly_thread:
            self._nightly_thread.join(timeout=5)
        self.narrative_store.stop()
        logger.info("✅ CognitionCore arrêté")

    def _cooling_loop(self):
        while self._running:
            time.sleep(CONFIG["cooling_interval_hours"] * 3600)
            self.graph.cool_down()

    def _nightly_loop(self):
        while self._running:
            now = datetime.now()
            if now.hour == CONFIG["nightly_hour"] and now.minute < 5:
                # Consolidation du graphe de connaissances
                self.graph.consolidate()
                # Archivage de la mémoire narrative du jour
                self.narrative_store.archive_today()
                time.sleep(3600)
            time.sleep(60)

    # ----------------------------------------------------------
    # POINT D'ENTRÉE (interface identique v10)
    # ----------------------------------------------------------

    def process(self, input_data: Union[str, Dict, "StructuredIntent"],
                input_type: str = "text",
                output_type: str = "intent") -> Union["StructuredIntent", str, None]:
        """
        Point d'entrée unique.

        input_type  : "text" | "intent"
        output_type : "intent" | "text"

        Après chaque appel, la couche supérieure peut accéder à :
          core.pending_curiosity      — intent de curiosité spontanée ou None
          core.conversation_summary   — résumé sémantique du fil
          core.affect_drift.snapshot()— état affectif courant {V, A, D}
        """
        # 1. Normaliser en intent
        if input_type == "text" and isinstance(input_data, str):
            intent = self._text_to_intent(input_data)
        elif input_type == "intent":
            if isinstance(input_data, StructuredIntent):
                intent = input_data
            elif isinstance(input_data, dict):
                intent = self._dict_to_intent(input_data)
            else:
                raise ValueError("input_type=intent mais input_data invalide")
        else:
            raise ValueError(f"input_type={input_type} non supporté")

        # 2. Traitement cognitif
        response_intent = self._cognize(intent)

        # 3. Sortie
        if output_type == "intent":
            return response_intent
        elif output_type == "text":
            return self.builder.build(response_intent, self.current_conversation)
        else:
            raise ValueError(f"output_type={output_type} non supporté")

    @property
    def pending_curiosity(self) -> Optional["StructuredIntent"]:
        """
        Intent de curiosité spontanée produit lors du dernier process().
        None si aucune curiosité n'a été générée.

        Usage typique :
            response = core.process(texte, output_type="text")
            if core.pending_curiosity:
                # Poser la question après un délai naturel
                question = core.pending_curiosity.attributes["question"].value
                print(question)
        """
        return self._pending_curiosity

    def consume_curiosity(self) -> Optional["StructuredIntent"]:
        """
        Retourne et efface l'intent de curiosité en attente.
        À appeler quand la couche supérieure décide de poser la question.
        """
        q = self._pending_curiosity
        self._pending_curiosity = None
        return q

    # ----------------------------------------------------------
    # TEXTE → INTENT (nouveau : via IntentParser)
    # ----------------------------------------------------------

    def _text_to_intent(self, text: str) -> "StructuredIntent":
        """
        Convertit un texte en StructuredIntent via IntentParser (spaCy).
        Fallback sur l'ancienne méthode basique si spaCy indisponible.
        """
        # Créer ou récupérer le contexte de conversation
        if not self.current_conversation or self.current_conversation.is_expired():
            self.current_conversation = ContextFrame(
                conversation_id=f"conv_{uuid.uuid4().hex[:8]}"
            )

        if self._parser is not None:
            # === NOUVEAU : IntentParser spaCy ===
            parse_result = self._parser.parse(
                text,
                context_frame=self.current_conversation,
                conversation_id=self.current_conversation.conversation_id,
                speaker=self.current_conversation.who or "unknown"
            )

            intent = ParseResultAdapter.to_intent(
                result=parse_result,
                conversation_id=self.current_conversation.conversation_id,
                speaker=self.current_conversation.who or "unknown",
                text=text,
                SourceInfo=SourceInfo,
                SourceWeight=SourceWeight,
                Attribute=Attribute,
                StructuredIntent=StructuredIntent
            )

        else:
            # === FALLBACK : parseur basique v10 ===
            intent = self._text_to_intent_fallback(text)

        # Mise à jour du contexte
        self._update_context_from_intent(intent)

        return intent

    def _update_context_from_intent(self, intent: "StructuredIntent"):
        """Met à jour le ContextFrame depuis un intent parsé."""
        if not self.current_conversation:
            return

        updates = {"history": [intent.id]}

        # Mettre à jour le sujet courant si une personne a été détectée
        if "personne" in intent.attributes:
            person_val = intent.attributes["personne"].value
            if isinstance(person_val, str):
                subjects = list(self.current_conversation.subjects)
                if person_val not in subjects:
                    subjects.append(person_val)
                updates["subjects"] = subjects[-10:]  # garder les 10 derniers

        self.current_conversation.update(**updates)

    def _text_to_intent_fallback(self, text: str) -> "StructuredIntent":
        """Parseur basique de secours (v10 original)."""
        intent_id = f"intent_{uuid.uuid4().hex[:8]}"
        text_lower = text.lower()

        if text_lower.endswith("?"):
            if "heure" in text_lower:
                intent_type, sub_intent = "question", "heure_actuelle"
            elif "qui" in text_lower:
                intent_type, sub_intent = "question", "identite_personne"
            elif "saison" in text_lower:
                intent_type, sub_intent = "question", "saison_actuelle"
            else:
                intent_type, sub_intent = "question", "general"
        elif any(w in text_lower for w in ["bonjour", "salut", "coucou", "hello"]):
            intent_type, sub_intent = "social", "salutation"
        elif any(w in text_lower for w in ["au revoir", "bye", "tchao"]):
            intent_type, sub_intent = "social", "conge"
        elif "merci" in text_lower:
            intent_type, sub_intent = "social", "remerciement"
        else:
            intent_type, sub_intent = "information", "statement"

        source = SourceInfo(type=SourceWeight.OBSERVATION)
        return StructuredIntent(
            id=intent_id,
            timestamp=time.time(),
            conversation_id=self.current_conversation.conversation_id,
            speaker=self.current_conversation.who or "unknown",
            semantic={
                "intent": intent_type,
                "sub_intent": sub_intent,
                "type": intent_type,
                "confidence": 0.6,
                "parser_version": "fallback_v10"
            },
            attributes={
                "text": Attribute(type="string", value=text, source=source)
            }
        )

    def _dict_to_intent(self, data: Dict) -> "StructuredIntent":
        """Reconstruit un StructuredIntent depuis un dict (identique v10)."""
        return StructuredIntent(
            id=data.get("id", f"intent_{uuid.uuid4().hex[:8]}"),
            timestamp=data.get("timestamp", time.time()),
            conversation_id=data.get("conversation_id", ""),
            speaker=data.get("speaker", "unknown"),
            semantic=data.get("semantic", {}),
            attributes={
                k: Attribute(
                    type=v["type"],
                    value=v["value"],
                    source=SourceInfo(type=SourceWeight(v.get("source", 0.9)))
                ) for k, v in data.get("attributes", {}).items()
            },
            signatures=data.get("signatures", {})
        )

    # ----------------------------------------------------------
    # ENTRÉE NARRATIVE PUBLIQUE
    # ----------------------------------------------------------

    def push_narrative(self, intent, source: str = "external"):
        """
        Reçoit un intent narratif depuis l'extérieur.
        Fire-and-forget — non bloquant.
        L'entité n'a pas à répondre, c'est une observation pure.

        source : qui envoie ("perception", "planificateur", "embodiment", etc.)
        """
        self.narrative_store.push(intent, source)

    # ----------------------------------------------------------
    # COGNIZE v12
    # ----------------------------------------------------------

    def _cognize(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Traitement cognitif principal v14.

        Après chaque tour :
        1. Identification par signature
        2. Routage cognitif
        3. Dérive affective selon le contenu
        4. Mise à jour du résumé conversationnel
        5. Génération d'une question de curiosité si pertinent
        """
        # Identification par signature
        if intent.signatures:
            if "voice" in intent.signatures:
                person = self.graph.find_by_signature_vocale(
                    intent.signatures["voice"]
                )
                if person:
                    intent.speaker = person.id
            if "face" in intent.signatures:
                person = self.graph.find_by_signature_visage(
                    intent.signatures["face"]
                )
                if person:
                    intent.speaker = person.id

        # Intent entrant actionable → action_queue
        sub_in = intent.semantic.get("sub_intent", "")
        if sub_in in self._actionable_intents["entrants"]:
            self.action_queue.put(intent)
            logger.debug(f"Intent entrant actionable routé : {sub_in}")

        # Routage cognitif
        intent_type = intent.semantic.get("type", "")

        if intent_type in (IntentType.QUESTION, "question"):
            if sub_in == "memoire_narrative":
                response = self._query_narrative(intent)
            elif sub_in == "preference":
                response = self._answer_preference(intent)
            else:
                response = self._answer_question(intent)
        elif intent_type in (IntentType.INFORMATION, "information"):
            if sub_in == "preference":
                response = self._update_preference(intent)
            else:
                response = self._store_information(intent)
        elif intent_type in (IntentType.SOCIAL, "social"):
            response = self._social_response(intent)
        elif intent_type in (IntentType.META, "meta"):
            response = self._meta_response(intent)
        else:
            response = self._default_response(intent)

        # Intent sortant actionable → action_queue
        sub_out = response.semantic.get("sub_intent", "")
        if sub_out in self._actionable_intents["sortants"]:
            self.action_queue.put(response)
            logger.debug(f"Intent sortant actionable routé : {sub_out}")

        # --- Post-traitement v14 ---

        # 1. Dérive affective selon le contenu de l'échange
        self._apply_affective_drift(intent, response)

        # 2. Mise à jour du résumé conversationnel
        self._update_conversation_summary(intent, response)

        # 3. Injecter l'affect courant dans le builder (AffectiveState réel)
        if hasattr(self.builder, "set_affect"):
            from grammar_engine import AffectiveState as _AS
            self.builder.set_affect(_AS(
                valence   = self.affect_drift.valence,
                arousal   = self.affect_drift.arousal,
                dominance = self.affect_drift.dominance
            ))

        # 4. Question de curiosité spontanée
        #    Générée après la réponse principale, attachée aux metadata
        #    ET émise comme intent séparé dans le flux de sortie.
        #    La couche supérieure peut choisir de la poser ou non.
        curiosity_q = self._generate_curiosity(intent, response)
        if curiosity_q:
            # Attacher aux metadata de la réponse
            if not hasattr(response, "metadata") or response.metadata is None:
                response.metadata = {}
            response.metadata["curiosity_question"] = curiosity_q

            # Émettre comme intent de curiosité autonome
            curiosity_intent = self._make_response(
                intent, "question", "curiosite_spontanee",
                confidence=getattr(self.gem, "curiosite_faits", 0.7),
                attributes={
                    "question": Attribute(
                        type="string",
                        value=curiosity_q,
                        source=SourceInfo(type=SourceWeight.SELF)
                    ),
                    "affect_snapshot": Attribute(
                        type="object",
                        value=self.affect_drift.snapshot(),
                        source=SourceInfo(type=SourceWeight.SELF)
                    )
                }
            )
            self.conversation_summary.ajouter_question_ouverte(curiosity_q)
            self.conversation_summary.derniere_curiosite = curiosity_q

            # Stocker pour que process() puisse le retourner
            self._pending_curiosity = curiosity_intent
        else:
            self._pending_curiosity = None

        return response

    def _query_narrative(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Interroge la mémoire narrative en lecture isolée.
        Les intents retournés n'entrent pas dans le graphe principal.
        """
        # Extraire les paramètres temporels depuis les attributs
        annee  = None
        mois   = None
        embodiment = None

        time_attr = intent.attributes.get("time") or intent.attributes.get("date")
        if time_attr:
            try:
                dt = datetime.fromisoformat(str(time_attr.value))
                annee = dt.year
                mois  = dt.month
            except (ValueError, TypeError):
                pass

        emb_attr = intent.attributes.get("embodiment")
        if emb_attr:
            embodiment = emb_attr.value

        sub_intent_filtre = intent.attributes.get("sub_intent_filtre")
        filtre = sub_intent_filtre.value if sub_intent_filtre else None

        # Lecture isolée
        entries = self.narrative_store.query(
            annee=annee,
            mois=mois,
            sub_intent=filtre,
            embodiment=embodiment,
            limit=50
        )

        return self._make_response(
            intent, "reponse", "memoire_narrative",
            confidence=1.0,
            attributes={
                "entries": Attribute(
                    type="list",
                    value=entries,
                    source=SourceInfo(type=SourceWeight.SELF)
                ),
                "count": Attribute(
                    type="number",
                    value=len(entries),
                    source=SourceInfo(type=SourceWeight.SELF)
                )
            }
        )

    def _answer_preference(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Répond à une question de préférence.

        Interroge le graphe pour l'état de préférence stocké sur le concept.
        Si absent → NE_SAIT_PAS.
        Si présent → retourne l'état avec sa justification si disponible.

        NOTE v13 : le calcul de valorisation (résonance Gem + expériences
        narratives + affect courant) est réservé pour PreferenceEngine.
        Ici on lit uniquement ce qui est déjà stocké dans le graphe.
        """
        # Extraire le sujet de la préférence
        sujet_attr = (intent.attributes.get("sujet")
                      or intent.attributes.get("concept")
                      or intent.attributes.get("personne")
                      or intent.attributes.get("objet"))

        if not sujet_attr:
            # Tenter d'extraire depuis le texte brut
            text = intent.attributes.get("text",
                   Attribute(type="string", value="")).value
            sujet_nom = self._extract_preference_subject(str(text))
        else:
            sujet_nom = str(sujet_attr.value)

        if not sujet_nom:
            return self._make_response(intent, "clarification", "general")

        # Chercher le concept dans le graphe
        concept = self.graph.get(sujet_nom)

        if not concept:
            # Concept inconnu → NE_SAIT_PAS
            return self._make_response(
                intent, "reponse", "preference",
                confidence=0.9,
                attributes={
                    "sujet": Attribute(
                        type="string", value=sujet_nom,
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    ),
                    "etat": Attribute(
                        type="preference_state",
                        value=PreferenceState.NE_SAIT_PAS.value,
                        source=SourceInfo(type=SourceWeight.SELF)
                    ),
                    "justification": Attribute(
                        type="string",
                        value=f"Je ne connais pas encore {sujet_nom}.",
                        source=SourceInfo(type=SourceWeight.SELF)
                    )
                }
            )

        # Lire l'état de préférence stocké sur le concept
        pref_prop = concept.proprietes.get("preference_state")

        if not pref_prop:
            # Concept connu mais jamais évalué → NE_SAIT_PAS
            etat = PreferenceState.NE_SAIT_PAS
            justification = (f"Je connais {concept.nom} mais "
                             f"je n'ai pas encore d'avis clair.")
        else:
            etat = PreferenceState(pref_prop.valeur)
            # Lire la justification si stockée
            just_prop = concept.proprietes.get("preference_justification")
            justification = (just_prop.valeur if just_prop
                             else self._build_justification(concept, etat))

        return self._make_response(
            intent, "reponse", "preference",
            confidence=0.9,
            attributes={
                "sujet": Attribute(
                    type="string", value=concept.nom,
                    source=SourceInfo(type=SourceWeight.OBSERVATION)
                ),
                "etat": Attribute(
                    type="preference_state", value=etat.value,
                    source=SourceInfo(type=SourceWeight.SELF)
                ),
                "justification": Attribute(
                    type="string", value=justification,
                    source=SourceInfo(type=SourceWeight.SELF)
                )
            }
        )

    def _update_preference(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Met à jour ou crée l'état de préférence pour un concept.

        Peut être appelé :
        - par une déclaration de l'interlocuteur ("tu aimes les chats ?")
          après que l'entité a répondu et confirmé
        - par une expérience significative signalée en intent entrant
        - par le PreferenceEngine (quand il sera branché)

        Règles :
        - NE_SAIT_PAS peut évoluer vers n'importe quel état
        - INDIFFERENT peut évoluer mais résiste davantage
        - AIME / AIME_PAS évoluent lentement (stabilité minimale RG7)
        - Un état ne change pas sans source identifiable (RG7)
        """
        sujet_attr = (intent.attributes.get("sujet")
                      or intent.attributes.get("concept")
                      or intent.attributes.get("personne"))

        etat_attr  = intent.attributes.get("etat")
        just_attr  = intent.attributes.get("justification")

        if not sujet_attr or not etat_attr:
            return self._make_response(intent, "clarification", "general")

        sujet_nom = str(sujet_attr.value)
        nouvel_etat_str = str(etat_attr.value)

        # Valider l'état
        try:
            nouvel_etat = PreferenceState(nouvel_etat_str)
        except ValueError:
            logger.warning(f"État de préférence invalide : {nouvel_etat_str}")
            return self._make_response(intent, "clarification", "general")

        # Récupérer ou créer le concept
        concept = self.graph.get(sujet_nom)
        if not concept:
            concept = self.graph.get_or_create(
                sujet_nom,
                ConceptNature.CATEGORIE,
                MemoryType.EPISODIQUE,
                SourceInfo(type=SourceWeight.OBSERVATION)
            )

        source = SourceInfo(
            type=SourceWeight.SELF,
            speaker="system",
            confidence=intent.semantic.get("confidence", 0.8)
        )

        # Lire l'état actuel
        etat_actuel_prop = concept.proprietes.get("preference_state")
        etat_actuel = (PreferenceState(etat_actuel_prop.valeur)
                       if etat_actuel_prop else None)

        # Vérifier la cohérence (RG7 — stabilité minimale)
        if etat_actuel and not self._preference_transition_allowed(
                etat_actuel, nouvel_etat, intent):
            logger.debug(
                f"Transition {etat_actuel} → {nouvel_etat} "
                f"refusée pour {sujet_nom} (stabilité)"
            )
            return self._make_response(
                intent, "acknowledge", "preference_stable"
            )

        # Écrire le nouvel état
        concept.add_propriete(
            "preference_state",
            nouvel_etat.value,
            "preference_state",
            source
        )

        # Écrire la justification si fournie
        if just_attr:
            concept.add_propriete(
                "preference_justification",
                str(just_attr.value),
                "texte",
                source
            )

        # Horodater l'évolution
        concept.add_propriete(
            "preference_updated_at",
            datetime.now().isoformat(),
            "datetime",
            source
        )

        logger.info(
            f"Préférence mise à jour : {sujet_nom} → {nouvel_etat.value}"
        )

        return self._make_response(
            intent, "acknowledge", "preference_updated",
            attributes={
                "sujet": Attribute(
                    type="string", value=sujet_nom,
                    source=SourceInfo(type=SourceWeight.SELF)
                ),
                "etat": Attribute(
                    type="preference_state", value=nouvel_etat.value,
                    source=SourceInfo(type=SourceWeight.SELF)
                )
            }
        )

    # ----------------------------------------------------------
    # Helpers préférences
    # ----------------------------------------------------------

    @staticmethod
    def _extract_preference_subject(text: str) -> Optional[str]:
        """
        Extrait le sujet d'une question de préférence depuis le texte brut.
        Heuristique simple — spaCy NER prendra le relais quand disponible.
        """
        patterns = [
            r"(?:aimes?[-\s]tu|tu aimes?|est[-\s]ce que tu aimes?)\s+([\w\s\-]+?)(?:\s*\?|$)",
            r"(?:qu(?:e|'est[-\s]ce que) tu penses? de)\s+([\w\s\-]+?)(?:\s*\?|$)",
            r"(?:ton avis sur|ta préférence pour)\s+([\w\s\-]+?)(?:\s*\?|$)",
        ]
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                return m.group(1).strip()
        return None

    @staticmethod
    def _preference_transition_allowed(
            actuel: "PreferenceState",
            nouveau: "PreferenceState",
            intent: "StructuredIntent") -> bool:
        """
        Vérifie si la transition d'état est autorisée.

        Règles de stabilité (RG7) :
        - NE_SAIT_PAS → tout : toujours autorisé
        - INDIFFERENT  → tout : autorisé avec source OBSERVATION ou SELF
        - NEUTRE       → AIME / AIME_PAS : autorisé
        - AIME         → AIME_PAS / NEUTRE : autorisé seulement si
                         source forte (OBSERVATION) ou expérience significative
        - AIME_PAS     → AIME / NEUTRE : idem
        """
        if actuel == PreferenceState.NE_SAIT_PAS:
            return True

        if actuel == PreferenceState.INDIFFERENT:
            return True

        if actuel == PreferenceState.NEUTRE:
            return True

        # AIME ou AIME_PAS — transition exige une source forte
        source_weight = intent.semantic.get("source_weight",
                        SourceWeight.OBSERVATION.value)
        return float(source_weight) >= SourceWeight.OBSERVATION.value

    def _build_justification(self, concept, etat: "PreferenceState") -> str:
        """
        Construit une justification minimale depuis les relations du graphe.
        Version squelette — sera enrichie par PreferenceEngine.
        """
        if etat == PreferenceState.NE_SAIT_PAS:
            return f"Je ne connais pas encore assez {concept.nom}."

        if etat == PreferenceState.INDIFFERENT:
            return f"{concept.nom.capitalize()} ne m'évoque rien de particulier."

        if etat == PreferenceState.NEUTRE:
            return (f"J'ai des avis partagés sur {concept.nom} — "
                    f"certains aspects m'attirent, d'autres moins.")

        # Chercher des caractéristiques dans le graphe
        carac = [
            r.cible for r in concept.get_relations()
            if hasattr(r, "type") and
            str(r.type) in ("a_pour_caracteristique", "RelationType.A_POUR_CARACTERISTIQUE")
        ]

        if carac and etat == PreferenceState.AIME:
            carac_str = ", ".join(carac[:2])
            return f"J'aime {concept.nom} — notamment pour {carac_str}."

        if carac and etat == PreferenceState.AIME_PAS:
            return f"{concept.nom.capitalize()} ne me convient pas vraiment."

        return (f"C'est mon ressenti pour {concept.nom}.")
        """
        Répond à une question.
        Gère les nouveaux sub_intents issus des patterns spaCy.
        """
        sub = intent.semantic.get("sub_intent", "")

        # ── Heure ──
        if sub in ("heure_actuelle", "time"):
            now = datetime.now()
            return self._make_response(
                intent, "reponse", "heure_actuelle",
                attributes={
                    "time": Attribute(
                        type="datetime",
                        value=now.isoformat(),
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    )
                }
            )

        # ── Saison ──
        elif sub in ("saison_actuelle", "saison"):
            saison = self._get_saison()
            return self._make_response(
                intent, "reponse", "saison_actuelle",
                attributes={
                    "saison": Attribute(
                        type="string",
                        value=saison,
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    )
                }
            )

        # ── Date ──
        elif sub in ("date_actuelle", "date"):
            now = datetime.now()
            return self._make_response(
                intent, "reponse", "date_actuelle",
                attributes={
                    "time": Attribute(
                        type="datetime",
                        value=now.isoformat(),
                        source=SourceInfo(type=SourceWeight.OBSERVATION)
                    )
                }
            )

        # ── Identité personne ──
        elif sub in ("identite_personne", "person"):
            return self._answer_person_question(intent)

        # ── Identité propre ──
        elif sub == "identite_self":
            return self._make_response(
                intent, "reponse", "identite_self",
                attributes={
                    "nom": Attribute(
                        type="string",
                        value=self.gem.nom,
                        source=SourceInfo(type=SourceWeight.SELF)
                    )
                }
            )

        # ── Question générale sans pattern matchant ──
        return self._make_response(intent, "clarification", "general")

    def _answer_person_question(self, intent: "StructuredIntent") -> "StructuredIntent":
        """Recherche une personne dans le graphe et répond."""
        # Récupérer le nom depuis le slot ou le texte brut
        person_attr = intent.attributes.get("personne")
        name = person_attr.value if person_attr else None

        if not name:
            # Tenter d'extraire depuis le texte
            text = intent.attributes.get("text", Attribute(type="string", value="")).value
            match = re.search(
                r"(?:qui est|c'est qui|tu connais)\s+([\w\s\-]+?)(?:\s*\?|$)",
                str(text), re.IGNORECASE
            )
            name = match.group(1).strip() if match else None

        if name:
            concept = self.graph.get(name)
            if concept:
                return self._make_response(
                    intent, "reponse", "person_info",
                    confidence=0.9,
                    attributes={
                        "person": Attribute(
                            type="object",
                            value={
                                "name": concept.nom,
                                "relations": [r.type.value for r in concept.get_relations()]
                            },
                            source=SourceInfo(type=SourceWeight.OBSERVATION)
                        )
                    }
                )

        # Personne inconnue → demande de clarification
        return self._make_response(
            intent, "clarification", "personne_inconnue",
            confidence=0.8,
            attributes={
                "personne": Attribute(
                    type="string",
                    value=name or "cette personne",
                    source=SourceInfo(type=SourceWeight.OBSERVATION)
                )
            }
        )

    def _store_information(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Stocke une information dans le graphe via le pattern Visiteur.

        L'intent est déjà parsé — IntentAnalyzer extrait les entités,
        relations et propriétés, puis dispatch sur les visiteurs :
          - GraphStorageVisitor      : écrit dans le graphe
          - ContextUpdateVisitor     : met à jour le ContextFrame
          - NarrativeVisitor         : pousse vers la mémoire narrative si significatif
          - AncrageLexicalVisitor    : observe les qualificatifs dans leur contexte
                                       affectif — construit la signification personnelle
        """
        # Récupérer l'état affectif courant depuis le builder si disponible
        affect_v, affect_a, affect_d = 0.0, 0.3, 0.6
        if hasattr(self.builder, "_external_affect") \
                and self.builder._external_affect is not None:
            af = self.builder._external_affect
            affect_v = getattr(af, "valence",   0.0)
            affect_a = getattr(af, "arousal",   0.3)
            affect_d = getattr(af, "dominance", 0.6)
        elif hasattr(self.gem, "humeur_actuelle"):
            # Fallback depuis l'humeur du Gem
            humeur_vad = {
                "joyeuse":  (0.8, 0.7, 0.8),
                "triste":   (-0.7, 0.2, 0.2),
                "sereine":  (0.6, 0.2, 0.7),
                "curieuse": (0.4, 0.6, 0.6),
                "neutre":   (0.0, 0.3, 0.6),
            }
            affect_v, affect_a, affect_d = humeur_vad.get(
                self.gem.humeur_actuelle, (0.0, 0.3, 0.6)
            )

        analyzer = IntentAnalyzer()
        analyzer.register(
            GraphStorageVisitor(
                graph            = self.graph,
                SourceInfo_cls   = SourceInfo,
                SourceWeight_cls = SourceWeight,
                ConceptNature_cls= ConceptNature,
                MemoryType_cls   = MemoryType,
                RelationType_cls = RelationType
            )
        ).register(
            ContextUpdateVisitor(self.current_conversation)
        ).register(
            NarrativeVisitor(self.narrative_store, intent)
        ).register(
            AncrageLexicalVisitor(
                ancrage_lexical  = self.ancrage_lexical,
                affect_valence   = affect_v,
                affect_arousal   = affect_a,
                affect_dominance = affect_d
            )
        )

        analyzer.analyze(intent)
        return self._make_response(intent, "acknowledge", "information")

    def _social_response(self, intent: "StructuredIntent") -> "StructuredIntent":
        """
        Répond aux échanges sociaux.
        Passe directement le sub_intent au builder (salutation, conge, etc.).
        """
        sub = intent.semantic.get("sub_intent", "salutation")

        # Transmettre le destinataire si disponible
        extra_attrs = {}
        if "destinataire" in intent.attributes:
            extra_attrs["destinataire"] = intent.attributes["destinataire"]

        return self._make_response(
            intent, "social", sub,
            confidence=1.0,
            attributes=extra_attrs
        )

    def _meta_response(self, intent: "StructuredIntent") -> "StructuredIntent":
        """Répond aux questions sur le système lui-même."""
        sub = intent.semantic.get("sub_intent", "")

        if sub == "identite_self":
            return self._make_response(
                intent, "reponse", "identite_self",
                attributes={
                    "nom": Attribute(
                        type="string",
                        value=self.gem.nom,
                        source=SourceInfo(type=SourceWeight.SELF)
                    )
                }
            )

        return self._default_response(intent)

    def _default_response(self, intent: "StructuredIntent") -> "StructuredIntent":
        return self._make_response(intent, "acknowledge", "default", confidence=0.7)

    # ----------------------------------------------------------
    # DÉRIVE AFFECTIVE v14
    # ----------------------------------------------------------

    def _apply_affective_drift(self, intent: "StructuredIntent",
                                response: "StructuredIntent"):
        """
        Applique une dérive légère du VAD selon le contenu de l'échange.

        Heuristiques :
          - Concept connu dans le graphe → stabilise (dominance +)
          - Concept inconnu              → curiosité (arousal +)
          - Réponse de clarification     → ambiguïté (dominance -)
          - Échange social positif       → valence +
          - Préférence positive exprimée → valence +
          - Ambiguïté répétée (3e fois)  → dominance -
        """
        sub_in  = intent.semantic.get("sub_intent", "")
        sub_out = response.semantic.get("sub_intent", "")
        conf    = float(response.semantic.get("confidence", 0.8))

        dv, da, dd = 0.0, 0.0, 0.0

        # Échange social → légère valence positive
        if intent.semantic.get("type") == "social":
            dv += 0.08

        # Concept connu → stabilité
        personne_attr = intent.attributes.get("personne") or \
                        intent.attributes.get("concept")
        if personne_attr:
            nom = str(personne_attr.value)
            if self.graph.get(nom):
                dd += 0.04   # concept connu → dominance +
            else:
                da += 0.06   # concept inconnu → curiosité

        # Clarification → ambiguïté → dominance -
        if sub_out in ("general", "unknown_word", "personne_inconnue"):
            dd -= 0.05

        # Faible confiance → incertitude
        if conf < 0.5:
            dd -= 0.04
            da += 0.03

        # Préférence positive exprimée
        if sub_out == "preference" and "etat" in response.attributes:
            etat = str(response.attributes["etat"].value)
            if etat == "aime":
                dv += 0.06
            elif etat == "aime_pas":
                dv -= 0.04

        # Appliquer la dérive
        if dv or da or dd:
            self.affect_drift.drift(dv, da, dd)

        # Retour lent vers l'équilibre (entre les tours)
        self.affect_drift.retour_equilibre(taux=0.01)

        logger.debug(
            f"AffectiveDrift → V={self.affect_drift.valence:+.3f} "
            f"A={self.affect_drift.arousal:.3f} "
            f"D={self.affect_drift.dominance:.3f}"
        )

    # ----------------------------------------------------------
    # RÉSUMÉ CONVERSATIONNEL v14
    # ----------------------------------------------------------

    def _update_conversation_summary(self, intent: "StructuredIntent",
                                      response: "StructuredIntent"):
        """
        Met à jour le résumé conversationnel après chaque tour.
        Extraction légère — pas de LLM, juste les entités disponibles.
        """
        summary = self.conversation_summary
        summary.incrementer_tour()

        # Sujets depuis les attributs de l'intent
        for slot in ("personne", "concept", "sujet", "objet", "lieu"):
            attr = intent.attributes.get(slot)
            if attr:
                summary.ajouter_sujet(str(attr.value))

        # Sujets depuis les entités NER
        ner = intent.attributes.get("_ner")
        if ner and ner.value:
            for ent in ner.value[:3]:
                text = ent.get("text", "").strip()
                if text and len(text) > 2:
                    summary.ajouter_sujet(text)

        # Fermer les questions ouvertes si réponse donnée
        sub_out = response.semantic.get("sub_intent", "")
        if sub_out not in ("general", "unknown_word", "personne_inconnue"):
            for slot in ("personne", "concept", "sujet"):
                attr = intent.attributes.get(slot)
                if attr:
                    summary.fermer_question(str(attr.value))

        # Valence de l'affect courant
        summary.noter_valence(self.affect_drift.valence)

        # Injecter le résumé dans le ContextFrame si disponible
        if self.current_conversation:
            try:
                self.current_conversation.update(
                    pending_fragments=[summary.to_context_string()]
                )
            except Exception:
                pass

    # ----------------------------------------------------------
    # CURIOSITÉ SPONTANÉE v14
    # ----------------------------------------------------------

    def _generate_curiosity(self, intent: "StructuredIntent",
                             response: "StructuredIntent") -> Optional[str]:
        """
        Génère une question de curiosité spontanée si les conditions
        sont réunies.

        Conditions :
        1. Un concept a été mentionné dans l'intent
        2. Ce concept est peu connu du graphe (peu de relations)
        3. La curiosité du Gem sur la dimension correspondante est élevée
        4. L'état affectif courant est compatible (arousal modéré+)

        La question est retournée comme string — elle sera ajoutée
        aux metadata de la réponse. C'est à la couche supérieure
        de décider si et quand la poser.
        """
        # Conditions préalables
        if self.affect_drift.arousal < 0.2:
            return None  # trop calme, pas de curiosité

        # Trouver le concept principal de l'intent
        concept_nom = None
        for slot in ("personne", "concept", "sujet", "objet"):
            attr = intent.attributes.get(slot)
            if attr:
                concept_nom = str(attr.value).strip()
                break

        if not concept_nom:
            return None

        # Vérifier la connaissance du concept dans le graphe
        concept = self.graph.get(concept_nom)

        # Curiosité selon le type de concept et les paramètres du Gem
        curiosite_seuil = getattr(self.gem, "seuil_curiosite", 0.7)

        if concept is None:
            # Concept totalement inconnu
            curiosite_generale = getattr(self.gem, "curiosite_faits", 0.7)
            if curiosite_generale >= curiosite_seuil:
                return self._formuler_question_curiosite(
                    concept_nom, "inconnu",
                    intent.semantic.get("sub_intent", "")
                )

        else:
            # Concept connu mais peu exploré
            nb_relations = len(concept.relations)
            nb_proprietes = len(concept.proprietes)

            nature_str = str(getattr(concept, "nature", "")).lower()

            # Curiosité selon la nature du concept
            curiosite_map = {
                "personne": getattr(self.gem, "curiosite_personnes", 0.9),
                "lieu":     getattr(self.gem, "curiosite_lieux",    0.8),
                "action":   getattr(self.gem, "curiosite_verbes",   0.5),
                "mot":      getattr(self.gem, "curiosite_mots",     0.6),
            }
            curiosite = curiosite_map.get(nature_str,
                        getattr(self.gem, "curiosite_faits", 0.7))

            # Générer une question si concept peu riche et curiosité haute
            if (curiosite >= curiosite_seuil
                    and nb_relations < 3
                    and nb_proprietes < 2):
                return self._formuler_question_curiosite(
                    concept_nom, nature_str,
                    intent.semantic.get("sub_intent", "")
                )

        return None

    def _formuler_question_curiosite(self, concept_nom: str,
                                      nature: str,
                                      sub_intent: str) -> str:
        """
        Formule une question de curiosité selon la nature du concept
        et le contexte conversationnel.
        """
        import random

        questions_personne = [
            f"Comment tu connais {concept_nom} ?",
            f"Depuis combien de temps tu connais {concept_nom} ?",
            f"Qu'est-ce qui te plaît chez {concept_nom} ?",
            f"Tu peux me dire quelque chose sur {concept_nom} ?",
        ]

        questions_lieu = [
            f"C'est comment, {concept_nom} ?",
            f"Tu y es souvent, à {concept_nom} ?",
            f"Pourquoi {concept_nom} ?",
        ]

        questions_generique = [
            f"Tu peux m'en dire plus sur {concept_nom} ?",
            f"C'est quoi exactement, {concept_nom} ?",
            f"Qu'est-ce que {concept_nom} représente pour toi ?",
        ]

        questions_inconnu = [
            f"Je ne connais pas {concept_nom} — c'est quoi ?",
            f"{concept_nom} ? Tu peux me présenter ?",
            f"Je n'ai pas encore rencontré {concept_nom}. Tu peux me dire qui c'est ?",
        ]

        pool_map = {
            "personne":  questions_personne,
            "lieu":      questions_lieu,
            "inconnu":   questions_inconnu,
        }

        pool = pool_map.get(nature, questions_generique)

        # Moduler légèrement selon l'affect
        if self.affect_drift.valence > 0.4:
            # Plus enthousiaste
            q = random.choice(pool)
            return q
        else:
            # Plus sobre
            return random.choice(questions_generique)

    # ----------------------------------------------------------
    # HELPER : fabrication d'un intent de réponse
    # ----------------------------------------------------------

    def _make_response(self, source_intent: "StructuredIntent",
                       intent_type: str, sub_intent: str,
                       confidence: float = 0.95,
                       attributes: Dict = None) -> "StructuredIntent":
        """Fabrique un StructuredIntent de réponse de façon concise."""
        return StructuredIntent(
            id=f"resp_{uuid.uuid4().hex[:8]}",
            timestamp=time.time(),
            conversation_id=source_intent.conversation_id,
            speaker="system",
            semantic={
                "intent": intent_type,
                "sub_intent": sub_intent,
                "type": intent_type,
                "confidence": confidence
            },
            attributes=attributes or {},
            in_response_to=source_intent.id
        )

    # ----------------------------------------------------------
    # UTILITAIRES
    # ----------------------------------------------------------

    @staticmethod
    def _get_saison() -> str:
        """Retourne la saison courante."""
        now = datetime.now()
        m, j = now.month, now.day
        if (m == 3 and j >= 20) or m in (4, 5) or (m == 6 and j < 21):
            return "printemps"
        if (m == 6 and j >= 21) or m in (7, 8) or (m == 9 and j < 22):
            return "été"
        if (m == 9 and j >= 22) or m in (10, 11) or (m == 12 and j < 21):
            return "automne"
        return "hiver"


# ============================================================
# POINT D'ENTRÉE (identique v10)
# ============================================================

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s.%(msecs)03d %(levelname)-8s [%(name)s] %(message)s",
        datefmt="%H:%M:%S"
    )

    data_path = Path("./data")
    gem_path = Path("./gem.json")
    bases_path = Path("./bases")

    # Vérifier que gem.json existe (sinon le créer comme en v10)
    if not gem_path.exists():
        example_gem = {
            "gem": {
                "identifiant": "shirka_demo",
                "nom": "Shirka",
                "date_naissance": datetime.now().isoformat(),
                "version": 1,
                "tempo_base": 0.65, "intensite_base": 0.7,
                "grace": 0.5, "reactivite": 0.8,
                "curiosite_mots": 0.8, "curiosite_verbes": 0.5,
                "curiosite_personnes": 0.9, "curiosite_lieux": 0.8,
                "curiosite_faits": 0.7,
                "affinites_litterature": {
                    "roman": 0.8, "poesie": 0.4, "theatre": 0.6, "essai": 0.7
                },
                "duree_memoire_litterature": 30,
                "duree_memoire_episodique": 90,
                "duree_memoire_sociale": 365,
                "style_prefere": "narratif",
                "seuil_curiosite": 0.7,
                "signature_type": "sha256",
                "signature_valeur": "demo"
            }
        }
        with open(gem_path, "w", encoding="utf-8") as f:
            json.dump(example_gem, f, indent=2)

    # Initialiser
    core = CognitionCore(
        data_path=data_path,
        gem_path=gem_path,
        patterns_dir=Path("./patterns"),
        templates_dir=Path("./templates")
    )

    # Charger les bases de connaissances
    temps_path = bases_path / "temps.json"
    if temps_path.exists():
        core.load_knowledge_base("temps", temps_path)

    core.start()

    # Tests
    test_phrases = [
        "bonjour",
        "c'est quelle saison ?",
        "quelle heure est-il ?",
        "il est quelle heure ?",          # → doit matcher comme v10 ne matchait pas
        "qui est Paul ?",
        "qui es-tu ?",                    # → meta / identite_self
        "salut tout le monde !",          # → social / salutation malgré "tout le monde"
        "tu peux me dire l'heure ?",      # → question / heure_actuelle
        "merci beaucoup",
        "au revoir",
        "bonne soirée"
    ]

    print("\n" + "="*60)
    print(f" TESTS — CognitionCore v{__version__}")
    print("="*60)

    for phrase in test_phrases:
        print(f"\n📥 '{phrase}'")

        try:
            intent = core.process(phrase, input_type="text", output_type="intent")
            parser_ver = intent.semantic.get("parser_version", "?")
            print(f"  Intent : {intent.semantic['intent']}/{intent.semantic['sub_intent']}"
                  f"  (conf={intent.semantic['confidence']:.2f}, parser={parser_ver})")

            texte = core.process(intent, input_type="intent", output_type="text")
            print(f"  Réponse: {texte}")

        except Exception as e:
            print(f"  ⚠️  Erreur : {e}")

    print("\n" + "="*60)
    print(" STATISTIQUES")
    print("="*60)
    print(f"Concepts en RAM     : {len(core.graph.ram_cache)}")
    if core._parser:
        print(f"Domaines patterns   : {core._parser.loaded_domains}")
    print(f"Domaines templates  : {core.builder.loaded_domains}")

    core.stop()
