"""
grammar_engine.py — Grammaire de génération française
Version 1.0.0

Architecture :
  Une grammaire de réécriture contextuelle où chaque règle est une fonction
  qui reçoit l'état affectif, le registre et le contexte sémantique,
  et retourne un fragment de phrase ou une liste de choix pondérés.

  Le moteur descend l'arbre de réécriture en prenant des décisions locales
  à chaque nœud selon :
    - L'état affectif (VAD : valence, arousal, dominance)
    - Le registre cible (familier / neutre / soutenu)
    - Le style du Gem
    - Le contexte sémantique (ce qu'on veut exprimer)

Structures couvertes :
  - Assertions simples et complexes
  - Questions (directes, indirectes, rhétoriques)
  - Réponses affectives (surprise, accord, désaccord)
  - Subordonnées (relative, causale, concessive, temporelle)

Usage :
    engine = GrammarEngine(morpho, lexicon, gem)
    
    phrase = engine.generate(
        intent_type="assertion",
        semantic={
            "sujet": "il",
            "predicat": "etre",
            "attribut": {"type": "heure", "valeur": datetime.now()}
        },
        affect=AffectiveState(valence=0.2, arousal=0.4, dominance=0.7),
        register="neutre"
    )
"""

import random
import re
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable, Tuple, Iterator
from enum import Enum

logger = logging.getLogger("GrammarEngine")


# ============================================================
# ÉTAT AFFECTIF
# ============================================================


# ============================================================
# ÉTAT AFFECTIF
# ============================================================

@dataclass
class AffectiveState:
    """
    Vecteur affectif VAD (Valence-Arousal-Dominance).
    
    valence   : -1.0 (très négatif) → +1.0 (très positif)
    arousal   : 0.0 (calme/fatigué) → 1.0 (très activé)
    dominance : 0.0 (subi, passif)  → 1.0 (maîtrisé, actif)
    
    Combinaisons typiques :
      joie        : valence=0.8,  arousal=0.7, dominance=0.8
      anxiété     : valence=-0.5, arousal=0.8, dominance=0.2
      tristesse   : valence=-0.7, arousal=0.2, dominance=0.2
      colère      : valence=-0.6, arousal=0.9, dominance=0.7
      sérénité    : valence=0.6,  arousal=0.2, dominance=0.7
      curiosité   : valence=0.4,  arousal=0.6, dominance=0.6
      surprise    : valence=0.1,  arousal=0.9, dominance=0.3
    """
    valence: float = 0.0      # neutre par défaut
    arousal: float = 0.3
    dominance: float = 0.6
    extra: Dict[str, float] = field(default_factory=dict)

    def distance(self, other: "AffectiveState") -> float:
        """Distance euclidienne dans l'espace VAD."""
        return (
            (self.valence - other.valence) ** 2 +
            (self.arousal - other.arousal) ** 2 +
            (self.dominance - other.dominance) ** 2
        ) ** 0.5

    @property
    def est_positif(self) -> bool:
        return self.valence > 0.2

    @property
    def est_negatif(self) -> bool:
        return self.valence < -0.2

    @property
    def est_active(self) -> bool:
        return self.arousal > 0.6

    @property
    def est_calme(self) -> bool:
        return self.arousal < 0.4

    @property
    def est_dominant(self) -> bool:
        return self.dominance > 0.6


# ============================================================
# RÔLES PROSODIQUES
# ============================================================

class ProsodyRole(str, Enum):
    """
    Rôle syntaxique d'un nœud dans la phrase.
    Détermine les valeurs prosodiques par défaut
    avant modulation affective.
    """
    SUJET        = "sujet"        # durée normale, accent faible
    VERBE        = "verbe"        # durée normale, légère montée
    ATTRIBUT     = "attribut"     # accent principal
    COMPLEMENT   = "complement"   # durée réduite, débit accéléré
    MODALISATEUR = "modalisateur" # doux, légèrement allongé
    INTENSIF     = "intensif"     # accent fort, durée étirée
    CONJONCTION  = "conjonction"  # rapide, non accentué
    PONCTUATION  = "ponctuation"  # pause pure, pas de voix
    INTERJECTION = "interjection" # forte, bref, accent maximal
    NEUTRE       = "neutre"       # pas de traitement spécial


# ============================================================
# NŒUD DE GRAMMAIRE
# ============================================================

@dataclass
class GrammarNode:
    """
    Un nœud de l'arbre de réécriture.
    Contient soit un texte terminal, soit des sous-nœuds.
    Porte un rôle prosodique utilisé par ProsodyEngine.
    """
    text: Optional[str] = None
    children: List["GrammarNode"] = field(default_factory=list)
    separator: str = " "
    optional: bool = False
    weight: float = 1.0
    role: ProsodyRole = ProsodyRole.NEUTRE   # ← nouveau

    @classmethod
    def terminal(cls, text: str, weight: float = 1.0,
                 role: ProsodyRole = ProsodyRole.NEUTRE) -> "GrammarNode":
        return cls(text=text, weight=weight, role=role)

    @classmethod
    def sequence(cls, *children, separator: str = " ",
                 role: ProsodyRole = ProsodyRole.NEUTRE) -> "GrammarNode":
        return cls(children=list(children), separator=separator, role=role)

    def realize(self) -> str:
        """Réalise le nœud en texte brut."""
        if self.text is not None:
            return self.text
        parts = [c.realize() for c in self.children if c is not None]
        parts = [p for p in parts if p]
        return self.separator.join(parts)

    def terminals(self) -> List["GrammarNode"]:
        """Retourne tous les nœuds terminaux en ordre linéaire."""
        if self.text is not None:
            return [self]
        result = []
        for child in self.children:
            if child is not None:
                result.extend(child.terminals())
        return result


# ============================================================
# SORTIE PARLÉE
# ============================================================

@dataclass
class SpeechToken:
    """
    Un mot ou une ponctuation avec ses paramètres prosodiques.

    word        : le mot tel qu'il sera prononcé
    duration_ms : durée de prononciation en millisecondes
    accent      : intensité de l'accent (0.0 = aucun, 1.0 = maximal)
    pitch_delta : variation de hauteur relative (-1.0 → +1.0)
    pause_after : pause après ce token en ms (0 = aucune)
    role        : rôle syntaxique source
    """
    word:        str
    duration_ms: int
    accent:      float
    pitch_delta: float
    pause_after: int
    role:        ProsodyRole = ProsodyRole.NEUTRE

    def to_ssml_token(self) -> str:
        """
        Produit un fragment SSML pour ce token.
        Compatible Amazon Polly / Google TTS / standard W3C.
        """
        parts = []

        # Pause avant si pitch monte (préparation accentuelle)
        if self.pause_after > 0 and self.role == ProsodyRole.PONCTUATION:
            return f'<break time="{self.pause_after}ms"/>'

        # Mot avec prosody
        rate = self._ms_to_rate(self.duration_ms, len(self.word))
        volume = self._accent_to_volume(self.accent)
        pitch = self._delta_to_pitch(self.pitch_delta)

        attrs = []
        if rate != "medium":
            attrs.append(f'rate="{rate}"')
        if volume != "medium":
            attrs.append(f'volume="{volume}"')
        if pitch != "+0%":
            attrs.append(f'pitch="{pitch}"')

        if attrs:
            inner = f'<prosody {" ".join(attrs)}>{self.word}</prosody>'
        else:
            inner = self.word

        if self.pause_after > 0:
            inner += f'<break time="{self.pause_after}ms"/>'

        return inner

    @staticmethod
    def _ms_to_rate(duration_ms: int, word_len: int) -> str:
        # Durée de référence : ~55ms par caractère, minimum 150ms
        # (les mots très courts ont un plancher)
        ref = max(word_len * 55, 150)
        ratio = duration_ms / ref
        if ratio < 0.70:  return "fast"
        if ratio < 0.88:  return "medium-fast"
        if ratio > 1.60:  return "slow"
        if ratio > 1.25:  return "medium-slow"
        return "medium"

    @staticmethod
    def _accent_to_volume(accent: float) -> str:
        if accent > 0.7:  return "loud"
        if accent > 0.4:  return "medium"
        if accent < 0.1:  return "soft"
        return "medium"

    @staticmethod
    def _delta_to_pitch(delta: float) -> str:
        if delta > 0.3:   return f"+{int(delta*20)}%"
        if delta < -0.3:  return f"{int(delta*20)}%"
        return "+0%"


@dataclass
class SpokenOutput:
    """
    Sortie complète du générateur avec texte et balisage prosodique.

    text   : texte brut ("Nous sommes en automne doré.")
    tokens : liste ordonnée des SpeechToken
    ssml   : fragment SSML complet prêt pour un TTS
    tagged : format custom "karaoke" lisible
             ex: [Nous/s120/a0.0][sommes/s140/a0.1][en/s80/a0.0]
                 [automne/s200/a0.7|+50ms][doré/s160/a0.4][./p300]
    """
    text:   str
    tokens: List[SpeechToken]
    ssml:   str   = field(init=False)
    tagged: str   = field(init=False)

    def __post_init__(self):
        self.ssml   = self._build_ssml()
        self.tagged = self._build_tagged()

    def _build_ssml(self) -> str:
        parts = ["<speak>"]
        for tok in self.tokens:
            parts.append(tok.to_ssml_token())
        parts.append("</speak>")
        return "".join(parts)

    def _build_tagged(self) -> str:
        """
        Format karaoke custom :
          [mot/dMs/aA/pPms/rROLE]
          d = durée ms, a = accent 0-9, p = pause après ms, r = rôle
        Exemple : [automne/d180/a7/p50/rATTRIBUT]
        """
        parts = []
        for tok in self.tokens:
            if tok.role == ProsodyRole.PONCTUATION:
                parts.append(f"[{tok.word}/p{tok.pause_after}]")
            else:
                accent_digit = int(tok.accent * 9)
                parts.append(
                    f"[{tok.word}"
                    f"/d{tok.duration_ms}"
                    f"/a{accent_digit}"
                    f"/p{tok.pause_after}"
                    f"/r{tok.role.value.upper()[:3]}"
                    f"]"
                )
        return " ".join(parts)


# ============================================================
# MOTEUR DE PROSODIE
# ============================================================

class ProsodyEngine:
    """
    Traverse les nœuds terminaux d'un arbre GrammarNode réalisé
    et produit une liste de SpeechToken modulée par l'état affectif.

    Paramètres prosodiques de base par rôle :
      (durée_ref_ms_par_syllabe, accent_base, pitch_base, pause_après_ms)

    Puis modulation globale par affect :
      - arousal élevé  → tout accéléré, accents compressés
      - arousal faible → tout ralenti, accents étirés
      - valence +      → pitch global légèrement haut
      - valence -      → pitch global légèrement bas
      - dominance -    → légère hésitation (pause pre-verbe)
    """

    # Durée de base par syllabe (ms), accent, pitch_delta, pause_après
    ROLE_PARAMS: Dict[ProsodyRole, Tuple[int, float, float, int]] = {
        ProsodyRole.SUJET:        (90,  0.15, 0.0,   0),
        ProsodyRole.VERBE:        (95,  0.25, 0.05,  0),
        ProsodyRole.ATTRIBUT:     (110, 0.70, 0.15,  0),
        ProsodyRole.COMPLEMENT:   (75,  0.10, -0.05, 0),
        ProsodyRole.MODALISATEUR: (105, 0.20, -0.1, 30),
        ProsodyRole.INTENSIF:     (120, 0.85, 0.25,  0),
        ProsodyRole.CONJONCTION:  (65,  0.05, 0.0,   0),
        ProsodyRole.PONCTUATION:  (0,   0.0,  0.0,   0),
        ProsodyRole.INTERJECTION: (85,  0.95, 0.35, 80),
        ProsodyRole.NEUTRE:       (90,  0.15, 0.0,   0),
    }

    # Pauses après ponctuation (ms)
    PAUSE_MAP = {
        ".":  350, "…": 450, "!": 300, "?": 320,
        ",":  120, ";": 180, ":": 150, "—": 200,
    }

    # Nombre de syllabes approximatif (heuristique française)
    @staticmethod
    def _syllabe_count(word: str) -> int:
        word = word.lower().strip(".,!?;:—\"'")
        if not word:
            return 1
        voyelles = set("aeiouyéèêëàâîïôùûü")
        count = 0
        prev_is_voyelle = False
        for ch in word:
            is_v = ch in voyelles
            if is_v and not prev_is_voyelle:
                count += 1
            prev_is_voyelle = is_v
        # e muet final ne compte pas (heuristique)
        if word.endswith("e") and count > 1:
            count -= 1
        return max(1, count)

    def build(self, root: GrammarNode,
              affect: AffectiveState,
              text: str) -> List[SpeechToken]:
        """
        Produit la liste complète de SpeechToken (mode batch).
        """
        return list(self.stream(root, affect, text))

    def stream(self, root: GrammarNode,
               affect: AffectiveState,
               text: str) -> Iterator[SpeechToken]:
        """
        Générateur : émet les SpeechToken un par un au fil de la traversée.
        Permet la consommation temps réel par le TTS sans attendre
        la fin de la réalisation.
        """
        terminals = root.terminals()
        role_map  = self._build_role_map(terminals)
        raw_tokens = re.findall(r"[\w''\u00e0-\u017e]+|[.,!?;:…—]", text)

        for raw in raw_tokens:
            if raw in self.PAUSE_MAP:
                pause = self._modulate_pause(self.PAUSE_MAP[raw], affect)
                yield SpeechToken(
                    word=raw, duration_ms=0, accent=0.0,
                    pitch_delta=0.0, pause_after=pause,
                    role=ProsodyRole.PONCTUATION
                )
                continue

            role = role_map.get(raw.lower(), ProsodyRole.NEUTRE)
            base_dur_per_syl, base_acc, base_pitch, base_pause = \
                self.ROLE_PARAMS[role]
            n_syl = self._syllabe_count(raw)
            duration_ms = base_dur_per_syl * n_syl

            duration_ms, accent, pitch_delta, pause_after = \
                self._modulate(duration_ms, base_acc, base_pitch,
                               base_pause, affect, role)

            yield SpeechToken(
                word=raw,
                duration_ms=int(duration_ms),
                accent=round(accent, 2),
                pitch_delta=round(pitch_delta, 2),
                pause_after=int(pause_after),
                role=role
            )

    def _align_tokens(self, terminals: List[GrammarNode],
                      text: str,
                      affect: AffectiveState) -> List[SpeechToken]:
        """
        Découpe le texte en mots, associe chaque mot au rôle
        du terminal source le plus proche, applique la modulation affective.
        """
        # Découpe simple : mots + ponctuations séparés
        raw_tokens = re.findall(r"[\w''\u00e0-\u017e]+|[.,!?;:…—]", text)

        # Construire un mapping mot → rôle depuis les terminaux
        role_map = self._build_role_map(terminals)

        tokens = []
        word_idx = 0

        for raw in raw_tokens:
            # Ponctuation pure
            if raw in self.PAUSE_MAP:
                pause = self.PAUSE_MAP[raw]
                # Modulation affect sur les pauses
                pause = self._modulate_pause(pause, affect)
                tokens.append(SpeechToken(
                    word=raw,
                    duration_ms=0,
                    accent=0.0,
                    pitch_delta=0.0,
                    pause_after=pause,
                    role=ProsodyRole.PONCTUATION
                ))
                continue

            # Chercher le rôle dans la map
            role = role_map.get(raw.lower(), ProsodyRole.NEUTRE)

            # Paramètres de base
            base_dur_per_syl, base_acc, base_pitch, base_pause = \
                self.ROLE_PARAMS[role]

            # Calculer la durée selon le nombre de syllabes
            n_syl = self._syllabe_count(raw)
            duration_ms = base_dur_per_syl * n_syl

            # Modulation affective
            duration_ms, accent, pitch_delta, pause_after = \
                self._modulate(duration_ms, base_acc, base_pitch,
                               base_pause, affect, role)

            tokens.append(SpeechToken(
                word=raw,
                duration_ms=int(duration_ms),
                accent=round(accent, 2),
                pitch_delta=round(pitch_delta, 2),
                pause_after=int(pause_after),
                role=role
            ))
            word_idx += 1

        return tokens

    def _build_role_map(self, terminals: List[GrammarNode]) -> Dict[str, ProsodyRole]:
        """
        Construit un dict mot_en_minuscule → ProsodyRole
        depuis les nœuds terminaux.
        """
        role_map: Dict[str, ProsodyRole] = {}
        for node in terminals:
            if node.text:
                # Découper le texte du nœud en mots
                words = re.findall(r"[\w''\u00e0-\u017e]+", node.text.lower())
                for w in words:
                    role_map[w] = node.role
        return role_map

    def _modulate(self, duration_ms: float, accent: float,
                  pitch_delta: float, pause_after: int,
                  affect: AffectiveState,
                  role: ProsodyRole) -> Tuple[float, float, float, int]:
        """
        Applique la modulation affective VAD sur les paramètres prosodiques.

        arousal élevé  → durées comprimées, accents réduits, débit rapide
        arousal faible → durées étirées, pauses allongées
        valence +      → pitch global +, accents sur attributs amplifiés
        valence -      → pitch global -, accents réduits sauf interjections
        dominance -    → légère hésitation (pause pré-verbe allongée)
        """
        a = affect.arousal
        v = affect.valence
        d = affect.dominance

        # --- Durée ---
        # Arousal comprime les durées (0.7 → ×0.85, 0.2 → ×1.2)
        duration_factor = 1.0 - (a - 0.3) * 0.5
        duration_ms *= max(0.6, min(1.4, duration_factor))

        # --- Accent ---
        # Valence amplifie les accents forts, atténue les faibles
        if v > 0.3 and role in (ProsodyRole.ATTRIBUT, ProsodyRole.INTENSIF,
                                  ProsodyRole.INTERJECTION):
            accent = min(1.0, accent * (1.0 + v * 0.3))
        elif v < -0.3:
            accent = accent * (1.0 + v * 0.2)  # réduction

        # Arousal élevé comprime les accents (tout se presse)
        if a > 0.7:
            accent *= 0.85

        # --- Pitch ---
        # Valence décale le pitch global
        pitch_delta += v * 0.15

        # Arousal élevé monte le pitch
        pitch_delta += (a - 0.3) * 0.1

        # --- Pause ---
        # Dominance faible → hésitation pré-verbe
        if d < 0.3 and role == ProsodyRole.VERBE:
            pause_after += int(80 * (0.3 - d) / 0.3)

        # Arousal élevé supprime les pauses
        if a > 0.7:
            pause_after = int(pause_after * 0.5)

        # Arousal faible allonge les pauses
        if a < 0.25:
            pause_after = int(pause_after * 1.5)

        return (
            max(50, duration_ms),
            max(0.0, min(1.0, accent)),
            max(-1.0, min(1.0, pitch_delta)),
            max(0, pause_after)
        )

    def _modulate_pause(self, pause_ms: int, affect: AffectiveState) -> int:
        """Modulation des pauses de ponctuation."""
        a = affect.arousal
        if a > 0.7:
            return int(pause_ms * 0.6)
        if a < 0.25:
            return int(pause_ms * 1.4)
        return pause_ms


# ============================================================
# LEXIQUE GÉNÉRATIF
# ============================================================

class GenerativeLexicon:
    """
    Lexique qui fournit les formes de surface selon
    le contexte grammatical et affectif.
    
    Puise dans les fiches de connaissance (usages_langagiers)
    et dans un lexique de base intégré.
    """

    # Verbe être conjugué
    ETRE = {
        "je": "suis", "tu": "es", "il": "est", "elle": "est",
        "on": "est", "nous": "sommes", "vous": "êtes",
        "ils": "sont", "elles": "sont", "ce": "est", "c'": "est"
    }

    # Verbe avoir conjugué
    AVOIR = {
        "je": "ai", "tu": "as", "il": "a", "elle": "a",
        "on": "a", "nous": "avons", "vous": "avez",
        "ils": "ont", "elles": "ont"
    }

    # Adverbes d'intensité selon arousal
    INTENSIFICATEURS = {
        "haut":  ["vraiment", "tellement", "si", "absolument"],
        "moyen": ["assez", "plutôt", "bien"],
        "bas":   ["un peu", "légèrement", "à peine"]
    }

    # Modalisateurs selon dominance
    MODALISATEURS = {
        "haut":  ["certainement", "évidemment", "clairement"],
        "moyen": ["probablement", "sans doute", "il me semble que"],
        "bas":   ["peut-être", "je crois que", "il me semble", "j'ai l'impression que"]
    }

    # Marqueurs discursifs selon registre
    MARQUEURS_ACCORD = {
        "familier": ["ouais", "exact", "c'est ça", "tout à fait", "carrément"],
        "neutre":   ["oui", "en effet", "c'est juste", "tout à fait"],
        "soutenu":  ["effectivement", "certes", "assurément", "c'est exact"]
    }

    MARQUEURS_DESACCORD = {
        "familier": ["non", "pas du tout", "c'est pas ça", "au contraire"],
        "neutre":   ["non", "pas exactement", "je ne crois pas", "au contraire"],
        "soutenu":  ["non", "je ne partage pas ce point de vue", "il me semble que non"]
    }

    MARQUEURS_SURPRISE = {
        "familier": ["oh !", "ah bon ?", "vraiment ?", "no way !", "sérieux ?"],
        "neutre":   ["oh !", "vraiment ?", "tiens !", "c'est surprenant"],
        "soutenu":  ["comme c'est surprenant", "voilà qui est inattendu", "tiens donc"]
    }

    # Conjonctions causales
    CAUSALES = {
        "familier": ["parce que", "vu que", "vu"],
        "neutre":   ["parce que", "car", "étant donné que", "puisque"],
        "soutenu":  ["car", "puisque", "étant donné que", "attendu que"]
    }

    # Conjonctions concessives
    CONCESSIVES = {
        "familier": ["mais", "même si", "quand même"],
        "neutre":   ["mais", "cependant", "même si", "bien que", "quoique"],
        "soutenu":  ["cependant", "néanmoins", "toutefois", "bien que", "quoique"]
    }

    # Conjonctions temporelles
    TEMPORELLES = {
        "familier": ["quand", "quand", "après que", "avant que"],
        "neutre":   ["quand", "lorsque", "après que", "avant que", "dès que"],
        "soutenu":  ["lorsque", "dès lors que", "sitôt que", "avant que"]
    }

    # Pronoms relatifs
    RELATIFS = {
        "sujet":  "qui",
        "objet":  "que",
        "lieu":   "où",
        "temps":  "où",
        "genitif": "dont"
    }

    def __init__(self, morpho, knowledge_bases: Dict = None):
        self.morpho = morpho
        self.knowledge_bases = knowledge_bases or {}

    def conjuguer_etre(self, sujet: str) -> str:
        return self.ETRE.get(sujet.lower(), "est")

    def conjuguer_avoir(self, sujet: str) -> str:
        return self.AVOIR.get(sujet.lower(), "a")

    def intensificateur(self, affect: AffectiveState) -> str:
        """Choisit un intensificateur selon l'arousal."""
        if affect.arousal > 0.7:
            pool = self.INTENSIFICATEURS["haut"]
        elif affect.arousal > 0.4:
            pool = self.INTENSIFICATEURS["moyen"]
        else:
            pool = self.INTENSIFICATEURS["bas"]
        return random.choice(pool)

    def modalisateur(self, affect: AffectiveState) -> str:
        """Choisit un modalisateur selon la dominance."""
        if affect.dominance > 0.7:
            pool = self.MODALISATEURS["haut"]
        elif affect.dominance > 0.4:
            pool = self.MODALISATEURS["moyen"]
        else:
            pool = self.MODALISATEURS["bas"]
        return random.choice(pool)

    def marqueur_accord(self, register: str, affect: AffectiveState) -> str:
        pool = self.MARQUEURS_ACCORD.get(register, self.MARQUEURS_ACCORD["neutre"])
        return random.choice(pool)

    def marqueur_desaccord(self, register: str, affect: AffectiveState) -> str:
        pool = self.MARQUEURS_DESACCORD.get(register, self.MARQUEURS_DESACCORD["neutre"])
        return random.choice(pool)

    def marqueur_surprise(self, register: str, affect: AffectiveState) -> str:
        pool = self.MARQUEURS_SURPRISE.get(register, self.MARQUEURS_SURPRISE["neutre"])
        return random.choice(pool)

    def conjonction_causale(self, register: str) -> str:
        return random.choice(self.CAUSALES.get(register, self.CAUSALES["neutre"]))

    def conjonction_concessive(self, register: str) -> str:
        return random.choice(self.CONCESSIVES.get(register, self.CONCESSIVES["neutre"]))

    def conjonction_temporelle(self, register: str) -> str:
        return random.choice(self.TEMPORELLES.get(register, self.TEMPORELLES["neutre"]))

    def collocation(self, concept: str, register: str) -> Optional[str]:
        """Cherche une collocation dans les fiches de connaissance."""
        base = self.knowledge_bases.get(concept, {})
        usages = base.get("usages_langagiers", {})
        cols = usages.get("collocations", [])
        reg_forms = usages.get("registres", {}).get(register, [])
        pool = reg_forms or cols
        return random.choice(pool) if pool else None


# ============================================================
# RÈGLES DE RÉÉCRITURE
# ============================================================

class FrenchGrammarRules:
    """
    Règles de réécriture pour le français.
    Chaque méthode correspond à un symbole non-terminal
    et retourne un GrammarNode.
    
    Conventions de nommage :
      r_  = règle de réécriture (retourne GrammarNode)
      _   = helper interne
    """

    def __init__(self, lexicon: GenerativeLexicon, morpho):
        self.lex = lexicon
        self.morpho = morpho

    # ----------------------------------------------------------
    # NIVEAU PHRASE
    # ----------------------------------------------------------

    def r_phrase(self, sem: Dict, affect: AffectiveState,
                 register: str) -> GrammarNode:
        """
        PHRASE → ASSERTION | QUESTION | REPONSE_AFFECTIVE | PHRASE_COMPLEXE
        """
        intent = sem.get("intent", "assertion")

        if intent == "assertion":
            return self.r_assertion(sem, affect, register)
        elif intent == "question":
            return self.r_question(sem, affect, register)
        elif intent == "reponse_affective":
            return self.r_reponse_affective(sem, affect, register)
        elif intent == "phrase_complexe":
            return self.r_phrase_complexe(sem, affect, register)
        else:
            return self.r_assertion(sem, affect, register)

    # ----------------------------------------------------------
    # ASSERTIONS
    # ----------------------------------------------------------

    def r_assertion(self, sem: Dict, affect: AffectiveState,
                    register: str, allow_modalizer: bool = True) -> GrammarNode:
        """
        ASSERTION → [MODALISATEUR] GN_SUJET GV [COMPLEMENT]*
        """
        children = []

        # Modalisateur si dominance faible — uniquement à la phrase racine
        if (allow_modalizer and affect.dominance < 0.4
                and random.random() < 0.5):
            mod = self.lex.modalisateur(affect)
            children.append(GrammarNode.terminal(mod,
                                role=ProsodyRole.MODALISATEUR))

        # Sujet
        gn = self.r_gn_sujet(sem, affect, register)
        children.append(gn)

        # Groupe verbal
        gv = self.r_gv(sem, affect, register)
        children.append(gv)

        # Compléments (omis si arousal très élevé → phrases courtes)
        if affect.arousal < 0.8 and "complement" in sem:
            comp = self.r_complement(sem["complement"], affect, register)
            children.append(comp)

        return GrammarNode.sequence(*children)

    def r_gn_sujet(self, sem: Dict, affect: AffectiveState,
                   register: str) -> GrammarNode:
        """GN_SUJET → PRONOM | DET NOM [ADJ]"""
        sujet = sem.get("sujet", "il")

        if sujet in {"je", "tu", "il", "elle", "on", "nous", "vous",
                     "ils", "elles", "ce", "c'"}:
            return GrammarNode.terminal(sujet, role=ProsodyRole.SUJET)

        genre  = sem.get("sujet_genre", "masc")
        nombre = sem.get("sujet_nombre", "sing")
        det    = self.morpho.article(sujet, "def", genre, nombre)
        nom    = sujet

        if (affect.est_positif and register == "soutenu"
                and "sujet_adj" in sem):
            adj = self.morpho.accord_adj(sem["sujet_adj"], genre, nombre)
            return GrammarNode.sequence(
                GrammarNode.terminal(det,  role=ProsodyRole.NEUTRE),
                GrammarNode.terminal(adj,  role=ProsodyRole.NEUTRE),
                GrammarNode.terminal(nom,  role=ProsodyRole.SUJET),
                role=ProsodyRole.SUJET
            )

        return GrammarNode.sequence(
            GrammarNode.terminal(det, role=ProsodyRole.NEUTRE),
            GrammarNode.terminal(nom, role=ProsodyRole.SUJET),
            role=ProsodyRole.SUJET
        )

    def r_gv(self, sem: Dict, affect: AffectiveState,
             register: str) -> GrammarNode:
        """GV → VERBE [INTENSIFICATEUR] ATTRIBUT | VERBE COMPLEMENT_VERBAL"""
        predicat = sem.get("predicat", "etre")
        sujet    = sem.get("sujet", "il")

        if predicat == "etre":
            verbe    = self.lex.conjuguer_etre(sujet)
            attribut = self._r_attribut(sem, affect, register)
            attr_type = sem.get("attribut_type", "")

            if (attr_type == "adjectif"
                    and affect.est_active and abs(affect.valence) > 0.5):
                if random.random() < 0.4:
                    intensif = self.lex.intensificateur(affect)
                    return GrammarNode.sequence(
                        GrammarNode.terminal(verbe,   role=ProsodyRole.VERBE),
                        GrammarNode.terminal(intensif,role=ProsodyRole.INTENSIF),
                        attribut,
                        role=ProsodyRole.VERBE
                    )

            return GrammarNode.sequence(
                GrammarNode.terminal(verbe, role=ProsodyRole.VERBE),
                attribut,
                role=ProsodyRole.VERBE
            )

        elif predicat == "avoir":
            verbe    = self.lex.conjuguer_avoir(sujet)
            attribut = self._r_attribut(sem, affect, register)
            return GrammarNode.sequence(
                GrammarNode.terminal(verbe, role=ProsodyRole.VERBE),
                attribut,
                role=ProsodyRole.VERBE
            )

        else:
            verbe_forme = sem.get("verbe_forme", predicat)
            children = [GrammarNode.terminal(verbe_forme, role=ProsodyRole.VERBE)]
            if "objet" in sem:
                obj = self._r_syntagme_nominal(
                    sem["objet"], sem.get("objet_genre", "masc"),
                    sem.get("objet_nombre", "sing"), affect, register
                )
                children.append(obj)
            return GrammarNode.sequence(*children, role=ProsodyRole.VERBE)

    def _r_attribut(self, sem: Dict, affect: AffectiveState,
                    register: str) -> GrammarNode:
        """ATTRIBUT → SN_HEURE | SN_DATE | SN_INTERVALLE | ADJ | NOM"""
        attr_type = sem.get("attribut_type", "nom")

        if attr_type == "heure":
            node = self._r_sn_heure(sem, affect, register)
        elif attr_type == "date":
            node = self._r_sn_date(sem, affect, register)
        elif attr_type in ("intervalle_temporel", "saison"):
            # "saison" conservé pour compatibilité ascendante —
            # les fiches peuvent encore l'envoyer, le moteur le traite
            # comme un intervalle générique.
            node = self._r_intervalle_temporel(sem, affect, register)
        elif attr_type == "adjectif":
            adj_base = sem.get("attribut_valeur", "")
            genre    = sem.get("sujet_genre", "masc")
            nombre   = sem.get("sujet_nombre", "sing")
            node = GrammarNode.terminal(
                self.morpho.accord_adj(adj_base, genre, nombre)
            )
        elif attr_type == "nom":
            node = self._r_syntagme_nominal(
                sem.get("attribut_valeur", ""),
                sem.get("attribut_genre", "masc"),
                sem.get("attribut_nombre", "sing"),
                affect, register
            )
        else:
            node = GrammarNode.terminal(str(sem.get("attribut_valeur", "")))

        node.role = ProsodyRole.ATTRIBUT
        return node

    def _r_sn_heure(self, sem: Dict, affect: AffectiveState,
                    register: str) -> GrammarNode:
        """
        SN_HEURE → heure_en_lettres | heure_chiffres
        
        Registre familier ou arousal élevé → chiffres
        Registre soutenu ou calme → lettres
        """
        dt = sem.get("attribut_valeur")
        if not isinstance(dt, datetime):
            try:
                dt = datetime.fromisoformat(str(dt))
            except (ValueError, TypeError):
                dt = datetime.now()

        if register == "familier" or affect.est_active:
            # Format chiffres : "14h32" ou "14h pile"
            if dt.minute == 0:
                texte = f"{dt.hour}h pile"
            else:
                texte = f"{dt.hour}h{dt.minute:02d}"
        elif register == "soutenu" or affect.est_calme:
            # Format lettres complet
            texte = self.morpho.heure_en_lettres(dt.hour, dt.minute)
        else:
            # Format mixte neutre
            if dt.minute == 0:
                texte = f"{dt.hour} heure{'s' if dt.hour != 1 else ''}"
            elif dt.minute == 30:
                texte = f"{dt.hour} heure{'s' if dt.hour != 1 else ''} et demie"
            elif dt.minute == 15:
                texte = f"{dt.hour} heure{'s' if dt.hour != 1 else ''} et quart"
            else:
                texte = f"{dt.hour} heure{'s' if dt.hour != 1 else ''} {dt.minute:02d}"

        return GrammarNode.terminal(texte)

    def _r_sn_date(self, sem: Dict, affect: AffectiveState,
                   register: str) -> GrammarNode:
        """SN_DATE → le JOUR_SEMAINE JOUR MOIS [ANNEE]"""
        dt = sem.get("attribut_valeur")
        if not isinstance(dt, datetime):
            try:
                dt = datetime.fromisoformat(str(dt))
            except (ValueError, TypeError):
                dt = datetime.now()

        jours = ["lundi", "mardi", "mercredi", "jeudi",
                 "vendredi", "samedi", "dimanche"]
        mois_noms = ["", "janvier", "février", "mars", "avril", "mai",
                     "juin", "juillet", "août", "septembre",
                     "octobre", "novembre", "décembre"]

        js = jours[dt.weekday()]
        j = "premier" if dt.day == 1 else str(dt.day)
        m = mois_noms[dt.month]

        # Arousal élevé → format court
        if affect.est_active:
            return GrammarNode.terminal(f"le {j} {m}")

        # Registre soutenu → avec année
        if register == "soutenu":
            return GrammarNode.terminal(
                f"le {js} {j} {m} {dt.year}"
            )

        return GrammarNode.terminal(f"le {js} {j} {m}")

    def _r_intervalle_temporel(self, sem: Dict, affect: AffectiveState,
                               register: str) -> GrammarNode:
        """
        SN_INTERVALLE → [PREP] NOM_INTERVALLE [ADJ_AFFECT]

        Gère tout intervalle temporel : saison, période de vacances,
        mois, ère, etc. Le moteur ne connaît pas les saisons en particulier —
        c'est le graphe de connaissances qui sait ce qu'est un intervalle
        et comment on en parle.

        sem attendu :
          attribut_valeur : str  — nom de l'intervalle ("hiver", "vacances de Pâques"…)
          attribut_prep   : str  — préposition (optionnelle, sinon inférée)
          attribut_genre  : str  — genre grammatical (défaut: masc)
          attribut_adjectifs : dict — {"positif": [...], "negatif": [...]} (optionnel)
        """
        nom_affiche = str(sem.get("attribut_valeur", "")).strip()
        nom         = nom_affiche.lower()
        genre       = sem.get("attribut_genre", "masc")

        # Préposition : fournie explicitement ou inférée
        prep = sem.get("attribut_prep")
        if not prep:
            # "printemps" commence par consonne → "au"
            # "été", "automne", "hiver" et tout mot commençant par voyelle → "en"
            if self.morpho.commence_par_voyelle(nom):
                prep = "en "
            else:
                # Masculin commençant par consonne → "au" pour les noms
                # d'intervalles (saisons, mois…)
                # Exception : mois de mars, mai, etc. → "en mars", "en mai"
                # Heuristique simple : si le graphe fournit attribut_prep, on s'y fie.
                # Sinon pour les intervalles temporels on préfère "en" universellement
                # sauf "printemps" qui prend "au".
                if nom == "printemps":
                    prep = "au "
                else:
                    prep = "en "

        # Adjectifs affectifs : depuis le graphe (sem) ou absents
        adjectifs = sem.get("attribut_adjectifs", {})

        if (adjectifs and abs(affect.valence) > 0.4
                and register != "familier"
                and random.random() < 0.5):
            pool_key = "positif" if affect.est_positif else "negatif"
            pool = adjectifs.get(pool_key, [])
            if pool:
                adj = random.choice(pool)
                adj_accorde = self.morpho.accord_adj(adj, genre, "sing")
                return GrammarNode.terminal(f"{prep}{nom_affiche} {adj_accorde}")

        return GrammarNode.terminal(f"{prep}{nom_affiche}")

    def _r_syntagme_nominal(self, nom: str, genre: str, nombre: str,
                             affect: AffectiveState,
                             register: str) -> GrammarNode:
        """SN → DET NOM [COMPLEMENT_NOM]"""
        if not nom:
            return GrammarNode.terminal("")
        det = self.morpho.article(nom, "def", genre, nombre)
        if nombre == "plur":
            nom_forme = self.morpho.pluriel(nom, genre)
        else:
            nom_forme = nom
        return GrammarNode.sequence(
            GrammarNode.terminal(det),
            GrammarNode.terminal(nom_forme)
        )

    def r_complement(self, comp: Dict, affect: AffectiveState,
                     register: str) -> GrammarNode:
        """COMPLEMENT → CC_LIEU | CC_TEMPS | CC_MANIERE"""
        comp_type = comp.get("type", "")

        if comp_type == "lieu":
            prep = comp.get("prep", "à")
            lieu = comp.get("valeur", "")
            return GrammarNode.terminal(f"{prep} {lieu}")

        elif comp_type == "temps":
            ref = comp.get("valeur", "")
            return GrammarNode.terminal(ref)

        elif comp_type == "maniere":
            return GrammarNode.terminal(comp.get("valeur", ""))

        return GrammarNode.terminal("")

    # ----------------------------------------------------------
    # QUESTIONS
    # ----------------------------------------------------------

    def r_question(self, sem: Dict, affect: AffectiveState,
                   register: str) -> GrammarNode:
        """
        QUESTION → Q_DIRECTE | Q_INDIRECTE | Q_RHETORIQUE
        
        Q_DIRECTE    → MOT_INTERROGATIF [SUJET] VERBE [COMPLEMENT] ?
        Q_INDIRECTE  → ASSERTION CONJ_Q Q_ENCHASSEE
        Q_RHETORIQUE → [MARQUEUR] MOT_INTERROGATIF DONC [ASSERTION]
        """
        q_type = sem.get("question_type", "directe")
        mot_q = sem.get("mot_interrogatif", "")
        sujet = sem.get("sujet", "il")

        if q_type == "directe":
            return self._r_question_directe(sem, affect, register)
        elif q_type == "indirecte":
            return self._r_question_indirecte(sem, affect, register)
        elif q_type == "rhetorique":
            return self._r_question_rhetorique(sem, affect, register)
        else:
            return self._r_question_directe(sem, affect, register)

    def _r_question_directe(self, sem: Dict, affect: AffectiveState,
                             register: str) -> GrammarNode:
        """
        Q_DIRECTE selon le registre :
          soutenu  → inversion : "Quelle heure est-il ?"
          neutre   → est-ce que : "Quelle heure est-ce qu'il est ?"
          familier → in situ   : "Il est quelle heure ?"
        """
        mot_q = sem.get("mot_interrogatif", "")
        sujet = sem.get("sujet", "il")
        predicat = sem.get("predicat", "etre")
        verbe = self.lex.conjuguer_etre(sujet) if predicat == "etre" \
            else sem.get("verbe_forme", predicat)

        attribut_node = self._r_attribut(sem, affect, register) \
            if "attribut_type" in sem else GrammarNode.terminal("")

        if register == "soutenu":
            # Inversion : "Quelle heure est-il ?"
            return GrammarNode.sequence(
                GrammarNode.terminal(mot_q),
                GrammarNode.terminal(f"{verbe}-{sujet} ?"),
                separator=" "
            )

        elif register == "familier" or affect.est_active:
            # In situ : "Il est quelle heure ?"
            return GrammarNode.terminal(
                f"{sujet.capitalize()} {verbe} {mot_q} ?"
            )

        else:
            # Est-ce que + élision devant voyelle
            sujet_elude = "qu'" if sujet.lower() in ("il", "elle", "on") else "que "
            constr = f"est-ce qu'{sujet} {verbe}" if sujet.lower() in ("il","elle","on") \
                else f"est-ce que {sujet} {verbe}"
            return GrammarNode.terminal(f"{mot_q} {constr} ?")

    def _r_question_indirecte(self, sem: Dict, affect: AffectiveState,
                               register: str) -> GrammarNode:
        """
        Q_INDIRECTE → "je me demande" | "je voudrais savoir" + SI/MOT_Q + PROPOSITION
        
        Typique des états de basse dominance (incertitude).
        """
        amorces = {
            "soutenu":  ["je me demande", "je souhaiterais savoir",
                         "il m'importe de savoir"],
            "neutre":   ["je me demande", "je voudrais savoir",
                         "j'aimerais savoir"],
            "familier": ["je sais pas", "je me demande bien",
                         "j'arrive pas à savoir"]
        }

        amorce = random.choice(amorces.get(register, amorces["neutre"]))
        mot_q = sem.get("mot_interrogatif", "si")
        sujet = sem.get("sujet", "il")
        predicat = sem.get("predicat", "etre")
        verbe = self.lex.conjuguer_etre(sujet) if predicat == "etre" \
            else sem.get("verbe_forme", predicat)

        # Élision : "si il" → "s'il"
        if mot_q == "si" and sujet.lower() in ("il", "ils"):
            liaison = f"s'{sujet}"
        else:
            liaison = f"{mot_q} {sujet}"

        return GrammarNode.terminal(
            f"{amorce} {liaison} {verbe}…"
        )

    def _r_question_rhetorique(self, sem: Dict, affect: AffectiveState,
                                register: str) -> GrammarNode:
        """
        Q_RHETORIQUE → n'est-ce pas ? | comment pourrait-il en être autrement ?
        
        Typique des états de haute dominance ou affect fort.
        """
        if register == "familier":
            formes = ["hein ?", "non ?", "c'est pas vrai ?", "t'imagines ?"]
        elif register == "soutenu":
            formes = ["n'est-ce pas ?", "comment pourrait-il en être autrement ?",
                      "n'est-il pas vrai que"]
        else:
            formes = ["n'est-ce pas ?", "non ?", "tu ne crois pas ?"]

        forme = random.choice(formes)
        proposition = sem.get("proposition", "")

        if proposition:
            return GrammarNode.sequence(
                GrammarNode.terminal(proposition),
                GrammarNode.terminal(","),
                GrammarNode.terminal(forme),
                separator=" "
            )
        return GrammarNode.terminal(forme)

    # ----------------------------------------------------------
    # RÉPONSES AFFECTIVES
    # ----------------------------------------------------------

    def r_reponse_affective(self, sem: Dict, affect: AffectiveState,
                             register: str) -> GrammarNode:
        """
        REPONSE_AFFECTIVE → SURPRISE | ACCORD | DESACCORD
        
        La structure varie selon l'arousal (phrase courte/longue)
        et la valence (positif/négatif).
        """
        r_type = sem.get("reponse_type", "accord")

        if r_type == "surprise":
            return self._r_surprise(sem, affect, register)
        elif r_type == "accord":
            return self._r_accord(sem, affect, register)
        elif r_type == "desaccord":
            return self._r_desaccord(sem, affect, register)
        else:
            return self._r_accord(sem, affect, register)

    def _r_surprise(self, sem: Dict, affect: AffectiveState,
                    register: str) -> GrammarNode:
        """
        SURPRISE → MARQUEUR_SURPRISE [PROPOSITION_COMMENTAIRE]
        
        Arousal élevé → juste le marqueur
        Arousal moyen → marqueur + commentaire court
        """
        marqueur = self.lex.marqueur_surprise(register, affect)

        if affect.arousal > 0.7:
            return GrammarNode.terminal(marqueur)

        # Commentaire
        commentaires = {
            "familier": ["j'aurais pas cru", "ça m'étonne",
                         "je l'aurais pas dit"],
            "neutre":   ["c'est surprenant", "je ne m'y attendais pas",
                         "c'est inattendu"],
            "soutenu":  ["voilà qui est pour le moins inattendu",
                         "je ne m'y attendais guère",
                         "c'est là quelque chose d'inhabituel"]
        }
        comm = random.choice(commentaires.get(register, commentaires["neutre"]))

        return GrammarNode.sequence(
            GrammarNode.terminal(marqueur),
            GrammarNode.terminal("—"),
            GrammarNode.terminal(comm)
        )

    def _r_accord(self, sem: Dict, affect: AffectiveState,
                  register: str) -> GrammarNode:
        """
        ACCORD → MARQUEUR_ACCORD [RENFORCEMENT_AFFECTIF] [PROPOSITION]
        """
        marqueur = self.lex.marqueur_accord(register, affect)

        # Renforcement si valence positive élevée
        if affect.valence > 0.6 and affect.arousal > 0.5:
            renforts = {
                "familier": ["et comment !", "tout à fait !", "complètement !"],
                "neutre":   ["tout à fait", "absolument", "c'est exactement ça"],
                "soutenu":  ["tout à fait", "assurément", "c'est précisément cela"]
            }
            renfort = random.choice(
                renforts.get(register, renforts["neutre"])
            )
            return GrammarNode.sequence(
                GrammarNode.terminal(marqueur),
                GrammarNode.terminal(","),
                GrammarNode.terminal(renfort)
            )

        # Accord simple
        proposition = sem.get("proposition", "")
        if proposition and affect.arousal < 0.6:
            return GrammarNode.sequence(
                GrammarNode.terminal(marqueur),
                GrammarNode.terminal(","),
                GrammarNode.terminal(proposition)
            )

        return GrammarNode.terminal(marqueur)

    def _r_desaccord(self, sem: Dict, affect: AffectiveState,
                     register: str) -> GrammarNode:
        """
        DESACCORD → MARQUEUR_DESACCORD [JUSTIFICATION]
        
        Dominance haute → désaccord direct
        Dominance basse → désaccord atténué + justification
        """
        if affect.dominance < 0.4:
            # Désaccord atténué
            attenuateurs = {
                "familier": ["enfin", "je sais pas", "c'est pas sûr"],
                "neutre":   ["je ne suis pas sûr", "pas nécessairement",
                             "il me semble que non"],
                "soutenu":  ["permettez-moi d'en douter",
                             "je ne suis pas certain",
                             "cela me semble discutable"]
            }
            att = random.choice(
                attenuateurs.get(register, attenuateurs["neutre"])
            )
            return GrammarNode.terminal(att)

        # Désaccord direct
        marqueur = self.lex.marqueur_desaccord(register, affect)
        proposition = sem.get("proposition_alternative", "")

        if proposition:
            conj = self.lex.conjonction_causale(register) \
                if sem.get("avec_justification") else "—"
            return GrammarNode.sequence(
                GrammarNode.terminal(marqueur),
                GrammarNode.terminal(","),
                GrammarNode.terminal(conj),
                GrammarNode.terminal(proposition)
            )

        return GrammarNode.terminal(marqueur)

    # ----------------------------------------------------------
    # PHRASES COMPLEXES
    # ----------------------------------------------------------

    def r_phrase_complexe(self, sem: Dict, affect: AffectiveState,
                           register: str) -> GrammarNode:
        """
        PHRASE_COMPLEXE → PRINCIPALE SUBORDONNEE
        
        Types : causale, concessive, relative, temporelle
        
        L'affect module le type de subordination préféré :
          - affect négatif + dominance basse → concessives (mais...)
          - affect positif + arousal élevé  → causales (parce que...)
          - affect calme                     → relatives (qui, que...)
        """
        sub_type = sem.get("sub_type")

        # Choix automatique si non spécifié
        if not sub_type:
            if affect.est_negatif and not affect.est_dominant:
                sub_type = "concessive"
            elif affect.est_positif and affect.est_active:
                sub_type = "causale"
            elif affect.est_calme:
                sub_type = "relative"
            else:
                sub_type = "causale"

        principale = sem.get("principale", {})
        subordonnee = sem.get("subordonnee", {})

        princ_node = self.r_assertion(principale, affect, register)

        if sub_type == "causale":
            conj = self.lex.conjonction_causale(register)
            sub_node = self.r_assertion(subordonnee, affect, register,
                                        allow_modalizer=False)
            return GrammarNode.sequence(
                princ_node,
                GrammarNode.terminal(conj),
                sub_node
            )

        elif sub_type == "concessive":
            conj = self.lex.conjonction_concessive(register)
            sub_node = self.r_assertion(subordonnee, affect, register,
                                        allow_modalizer=False)
            return GrammarNode.sequence(
                princ_node,
                GrammarNode.terminal(","),
                GrammarNode.terminal(conj),
                sub_node
            )

        elif sub_type == "relative":
            antecedent = sem.get("antecedent", "")
            fonction = sem.get("fonction_relative", "sujet")
            pronom_rel = self.lex.RELATIFS.get(fonction, "qui")
            sub_node = self.r_assertion(subordonnee, affect, register,
                                        allow_modalizer=False)
            return GrammarNode.sequence(
                princ_node,
                GrammarNode.terminal(antecedent),
                GrammarNode.terminal(pronom_rel),
                sub_node
            )

        elif sub_type == "temporelle":
            conj = self.lex.conjonction_temporelle(register)
            sub_node = self.r_assertion(subordonnee, affect, register,
                                        allow_modalizer=False)
            sub_text = sub_node.realize()
            # Élision de la conjonction devant voyelle
            conj_final = self.morpho.elider(f"{conj} {sub_text[:20]}").split()[0] \
                if conj.endswith("e") else conj

            if affect.est_calme and register == "soutenu":
                return GrammarNode.terminal(
                    f"{conj.capitalize()} {sub_text}, {princ_node.realize()}"
                )
            return GrammarNode.terminal(
                f"{princ_node.realize()} {conj} {sub_text}"
            )

        return princ_node


# ============================================================
# MOTEUR PRINCIPAL
# ============================================================

class GrammarEngine:
    """
    Moteur de génération par grammaire de réécriture.
    
    Interface publique :
        engine.generate(intent_type, semantic, affect, register)
        → str
    """

    def __init__(self, morpho, knowledge_bases: Dict = None, gem=None):
        self.morpho = morpho
        self.gem = gem
        self.lexicon = GenerativeLexicon(morpho, knowledge_bases or {})
        self.rules = FrenchGrammarRules(self.lexicon, morpho)

    def generate(self, intent_type: str,
                 semantic: Dict[str, Any],
                 affect: Optional[AffectiveState] = None,
                 register: Optional[str] = None,
                 spoken: bool = False):
        """
        Génère une phrase. Retourne str ou SpokenOutput selon spoken.
        """
        if affect is None:
            affect = self._affect_from_gem()
        if register is None:
            register = self._register_from_gem(affect)

        sem = {"intent": intent_type, **semantic}

        try:
            node = self.rules.r_phrase(sem, affect, register)
            text = node.realize()
        except Exception as e:
            logger.error(f"Erreur de génération : {e}")
            if spoken:
                return SpokenOutput(text="…", tokens=[])
            return "…"

        text = self._post_process(text, affect)

        logger.debug(
            f"generate({intent_type}) "
            f"affect=({affect.valence:.1f},{affect.arousal:.1f},{affect.dominance:.1f}) "
            f"register={register} → '{text}'"
        )

        if not spoken:
            return text

        prosody = ProsodyEngine()
        tokens  = prosody.build(node, affect, text)
        return SpokenOutput(text=text, tokens=tokens)

    def generate_stream(self, intent_type: str,
                        semantic: Dict[str, Any],
                        affect: Optional[AffectiveState] = None,
                        register: Optional[str] = None,
                        stream=None) -> "ProductionStream":
        """
        Génère une phrase et l'émet token par token dans un ProductionStream.

        Le producteur tourne dans un thread daemon séparé.
        Le caller reçoit le stream immédiatement et peut commencer
        à consommer token_queue pendant que la production continue.

        stream : ProductionStream existant (optionnel).
                 Si None, un nouveau est créé.

        Usage :
            stream = engine.generate_stream("assertion", sem, affect)
            for token in stream.iter_tokens():
                tts.speak(token)
            full_text = stream.get_text()
        """
        import threading
        from production_stream import ProductionStream as PS

        if stream is None:
            from production_stream import ProductionStream as PS
            stream = PS()

        if affect is None:
            affect = self._affect_from_gem()
        if register is None:
            register = self._register_from_gem(affect)

        sem = {"intent": intent_type, **semantic}

        def _produce():
            try:
                node = self.rules.r_phrase(sem, affect, register)
                text = node.realize()
                text = self._post_process(text, affect)

                prosody = ProsodyEngine()

                for token in prosody.stream(node, affect, text):
                    if stream.interrupted:
                        # Émettre un token de clôture propre
                        closing = stream.get_closing_token(SpeechToken, ProsodyRole)
                        stream.put_token(closing)
                        break
                    if not stream.put_token(token):
                        break

            except Exception as e:
                logger.error(f"Erreur de production stream : {e}")
            finally:
                stream.done()

        t = threading.Thread(target=_produce, daemon=True,
                             name="grammar-producer")
        t.start()
        return stream

    def _affect_from_gem(self) -> AffectiveState:
        """Construit un AffectiveState depuis l'humeur du Gem."""
        if self.gem is None:
            return AffectiveState()

        humeur_map = {
            "joyeuse":    AffectiveState(0.8, 0.7, 0.8),
            "triste":     AffectiveState(-0.7, 0.2, 0.2),
            "anxieuse":   AffectiveState(-0.5, 0.8, 0.2),
            "sereine":    AffectiveState(0.6, 0.2, 0.7),
            "curieuse":   AffectiveState(0.4, 0.6, 0.6),
            "en colere":  AffectiveState(-0.6, 0.9, 0.7),
            "neutre":     AffectiveState(0.0, 0.3, 0.6),
        }
        return humeur_map.get(
            self.gem.humeur_actuelle,
            AffectiveState()
        )

    def _register_from_gem(self, affect: AffectiveState) -> str:
        """Infère le registre depuis le Gem et l'affect."""
        if self.gem is None:
            return "neutre"

        grace = getattr(self.gem, "grace", 0.5)
        reactivite = getattr(self.gem, "reactivite", 0.5)

        if grace >= 0.7 and affect.est_calme:
            return "soutenu"
        if reactivite >= 0.8 or affect.est_active:
            return "familier"
        return "neutre"

    def _post_process(self, text: str, affect: AffectiveState) -> str:
        """
        Post-traitement :
        - Élisions
        - Majuscule initiale
        - Ponctuation finale modulée par l'affect
        - Nettoyage des espaces
        """
        import re

        # Élisions standard
        text = self.morpho.elider(text)

        # Élisions des locutions conjonctives
        import re
        text = re.sub(r"\bque il\b", "qu'il", text)
        text = re.sub(r"\bque elle\b", "qu'elle", text)
        text = re.sub(r"\bque ils\b", "qu'ils", text)
        text = re.sub(r"\bque elles\b", "qu'elles", text)
        text = re.sub(r"\bque on\b", "qu'on", text)
        text = re.sub(r"\bsi il\b", "s'il", text)
        text = re.sub(r"\bsi ils\b", "s'ils", text)

        # Nettoyage espaces
        text = re.sub(r"\s+", " ", text).strip()
        text = re.sub(r" ([,.!?;:])", r"\1", text)
        text = re.sub(r" - ", "-", text)

        # Majuscule
        text = self.morpho.majuscule(text)

        # Ponctuation terminale selon affect
        if text and text[-1] not in ".!?…":
            if affect.est_active and affect.est_positif:
                text += " !"
            elif affect.arousal < 0.2:
                text += "…"
            else:
                text += "."

        return text

    def update_knowledge(self, knowledge_bases: Dict):
        """Met à jour les bases de connaissance du lexique."""
        self.lexicon.knowledge_bases.update(knowledge_bases)


# ============================================================
# TESTS
# ============================================================

if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")
    from french_morphology import FrenchMorphology

    logging.basicConfig(level=logging.DEBUG,
                        format="%(levelname)-8s [%(name)s] %(message)s")

    morpho = FrenchMorphology()
    engine = GrammarEngine(morpho)

    now = datetime.now()

    print("\n" + "="*60)
    print(" ASSERTIONS")
    print("="*60)

    tests_assertions = [
        ("Il est 14h30 — neutre calme", {
            "sujet": "il", "predicat": "etre",
            "attribut_type": "heure", "attribut_valeur": now
        }, AffectiveState(0.0, 0.3, 0.6), "neutre"),

        ("Il est 14h30 — familier activé", {
            "sujet": "il", "predicat": "etre",
            "attribut_type": "heure", "attribut_valeur": now
        }, AffectiveState(0.2, 0.8, 0.7), "familier"),

        ("Il est 14h30 — soutenu calme", {
            "sujet": "il", "predicat": "etre",
            "attribut_type": "heure", "attribut_valeur": now
        }, AffectiveState(0.4, 0.2, 0.8), "soutenu"),

        ("Saison — joie", {
            "sujet": "nous", "predicat": "etre",
            "attribut_type": "saison", "attribut_valeur": "automne"
        }, AffectiveState(0.8, 0.7, 0.8), "neutre"),

        ("Saison — tristesse", {
            "sujet": "nous", "predicat": "etre",
            "attribut_type": "saison", "attribut_valeur": "hiver"
        }, AffectiveState(-0.7, 0.2, 0.2), "neutre"),
    ]

    for label, sem, affect, reg in tests_assertions:
        result = engine.generate("assertion", sem, affect, reg)
        print(f"  {label:<35} → {result}")

    print("\n" + "="*60)
    print(" QUESTIONS")
    print("="*60)

    tests_questions = [
        ("Heure — soutenu", {
            "question_type": "directe",
            "mot_interrogatif": "quelle heure",
            "sujet": "il", "predicat": "etre"
        }, AffectiveState(0.0, 0.3, 0.8), "soutenu"),

        ("Heure — neutre", {
            "question_type": "directe",
            "mot_interrogatif": "quelle heure",
            "sujet": "il", "predicat": "etre"
        }, AffectiveState(0.0, 0.4, 0.6), "neutre"),

        ("Heure — familier", {
            "question_type": "directe",
            "mot_interrogatif": "quelle heure",
            "sujet": "il", "predicat": "etre"
        }, AffectiveState(0.0, 0.7, 0.6), "familier"),

        ("Indirecte — incertitude", {
            "question_type": "indirecte",
            "mot_interrogatif": "si",
            "sujet": "il", "predicat": "etre"
        }, AffectiveState(-0.2, 0.4, 0.2), "neutre"),
    ]

    for label, sem, affect, reg in tests_questions:
        result = engine.generate("question", sem, affect, reg)
        print(f"  {label:<35} → {result}")

    print("\n" + "="*60)
    print(" RÉPONSES AFFECTIVES")
    print("="*60)

    tests_affectifs = [
        ("Surprise — arousal élevé", {
            "reponse_type": "surprise"
        }, AffectiveState(0.1, 0.9, 0.3), "familier"),

        ("Accord — joie forte", {
            "reponse_type": "accord"
        }, AffectiveState(0.9, 0.8, 0.8), "neutre"),

        ("Désaccord — dominance haute", {
            "reponse_type": "desaccord",
            "proposition_alternative": "ce n'est pas tout à fait exact",
            "avec_justification": True
        }, AffectiveState(-0.3, 0.6, 0.8), "soutenu"),

        ("Désaccord — dominance basse", {
            "reponse_type": "desaccord"
        }, AffectiveState(-0.2, 0.4, 0.2), "neutre"),
    ]

    for label, sem, affect, reg in tests_affectifs:
        result = engine.generate("reponse_affective", sem, affect, reg)
        print(f"  {label:<35} → {result}")

    print("\n" + "="*60)
    print(" PHRASES COMPLEXES")
    print("="*60)

    principale = {
        "sujet": "je", "predicat": "etre",
        "attribut_type": "adjectif", "attribut_valeur": "heureux",
        "sujet_genre": "masc", "sujet_nombre": "sing"
    }
    subordonnee = {
        "sujet": "il", "predicat": "etre",
        "attribut_type": "saison", "attribut_valeur": "printemps"
    }

    tests_complexes = [
        ("Causale — joie", {
            "sub_type": "causale",
            "principale": principale,
            "subordonnee": subordonnee
        }, AffectiveState(0.8, 0.7, 0.8), "neutre"),

        ("Concessive — tristesse", {
            "sub_type": "concessive",
            "principale": principale,
            "subordonnee": subordonnee
        }, AffectiveState(-0.5, 0.3, 0.3), "neutre"),

        ("Temporelle — soutenu", {
            "sub_type": "temporelle",
            "principale": principale,
            "subordonnee": subordonnee
        }, AffectiveState(0.3, 0.2, 0.7), "soutenu"),
    ]

    for label, sem, affect, reg in tests_complexes:
        result = engine.generate("phrase_complexe", sem, affect, reg)
        print(f"  {label:<35} → {result}")
