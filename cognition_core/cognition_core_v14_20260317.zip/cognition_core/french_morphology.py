"""
french_morphology.py — Moteur morphologique français complet
Version 1.0.0

Fonctionnalités :
- Accord en genre et en nombre (adjectifs, participes)
- Articles définis / indéfinis / contractés avec élision
- Pluriels réguliers et irréguliers
- Féminins réguliers et irréguliers
- Majuscule de début de phrase
- Élision : le/la → l' devant voyelle ou h muet
- Contraction : de + le → du, de + les → des, à + le → au, à + les → aux
- Conjugaison présent des auxiliaires (être, avoir) — pour les templates
- Transformation de nombres en lettres (heures, minutes)

Usage :
    morpho = FrenchMorphology()
    morpho.accord_adj("grand", genre="fem", nombre="sing")  # → "grande"
    morpho.article("chien", "def", "masc", "sing")          # → "le"
    morpho.article("eau", "def", "fem", "sing")             # → "l'"
    morpho.contraction("de", "le", "chien")                 # → "du"
    morpho.pluriel("cheval")                                 # → "chevaux"
"""

import re
import unicodedata
from typing import Optional, Dict, Tuple


# ============================================================
# LEXIQUES
# ============================================================

# Mots commençant par h muet (élision obligatoire)
H_MUET = {
    "homme", "heure", "habitude", "haleine", "harmonie", "hiver",
    "histoire", "honneur", "hôpital", "hôtel", "humeur", "humour",
    "herbe", "horreur", "horizon", "humanité", "humble", "humide"
}

# Mots commençant par h aspiré (pas d'élision)
H_ASPIRE = {
    "haricot", "hibou", "hiboux", "hockey", "hamburger", "hamster",
    "harpe", "héros", "honte", "hors", "huit"
}

# Pluriels irréguliers
PLURIELS_IRREGULIERS: Dict[str, str] = {
    "oeil": "yeux", "aïeul": "aïeux", "ciel": "cieux",
    "vitrail": "vitraux", "corail": "coraux", "travail": "travaux",
    "bail": "baux", "émail": "émaux", "soupirail": "soupiraux",
    "cheval": "chevaux", "journal": "journaux", "animal": "animaux",
    "capital": "capitaux", "général": "généraux", "original": "originaux",
    "festival": "festivals", "bal": "bals", "carnaval": "carnavals",
    "récital": "récitals", "régal": "régals",
    "genou": "genoux", "caillou": "cailloux", "hibou": "hiboux",
    "joujou": "joujoux", "pou": "poux", "chou": "choux",
    "bijou": "bijoux", "trou": "trous",
    "monsieur": "messieurs", "madame": "mesdames",
    "mademoiselle": "mesdemoiselles"
}

# Féminins irréguliers (masculin → féminin)
FEMININS_IRREGULIERS: Dict[str, str] = {
    # -eur → -euse
    "chanteur": "chanteuse", "vendeur": "vendeuse", "danseur": "danseuse",
    "nageur": "nageuse", "voyageur": "voyageuse", "joueur": "joueuse",
    # -eur → -rice
    "acteur": "actrice", "directeur": "directrice", "lecteur": "lectrice",
    "docteur": "doctoresse", "instituteur": "institutrice",
    "traducteur": "traductrice", "réalisateur": "réalisatrice",
    # -er → -ère
    "boulanger": "boulangère", "épicier": "épicière", "infirmier": "infirmière",
    "berger": "bergère", "étranger": "étrangère",
    # doubles consonnes
    "chat": "chatte", "chien": "chienne", "lion": "lionne",
    "baron": "baronne", "paysan": "paysanne",
    # irréguliers complets
    "homme": "femme", "frère": "sœur", "père": "mère",
    "roi": "reine", "dieu": "déesse", "héros": "héroïne",
    "prince": "princesse", "duc": "duchesse",
    "neveu": "nièce", "compagnon": "compagne"
}

# Adjectifs irréguliers (masc_sing → fem_sing)
ADJ_IRREGULIERS: Dict[str, str] = {
    "beau": "belle", "nouveau": "nouvelle", "vieux": "vieille",
    "long": "longue", "blanc": "blanche", "franc": "franche",
    "public": "publique", "grec": "grecque", "sec": "sèche",
    "bas": "basse", "gras": "grasse", "las": "lasse",
    "gros": "grosse", "faux": "fausse", "doux": "douce",
    "roux": "rousse", "jaloux": "jalouse",
    "actif": "active", "naïf": "naïve", "vif": "vive",
    "sportif": "sportive", "positif": "positive",
    "heureux": "heureuse", "sérieux": "sérieuse",
    "amoureux": "amoureuse", "courageux": "courageuse",
    "bon": "bonne", "mignon": "mignonne", "ancien": "ancienne",
    "européen": "européenne", "moyen": "moyenne",
    "complet": "complète", "secret": "secrète", "discret": "discrète",
    "inquiet": "inquiète", "concret": "concrète",
    "grand": "grande", "petit": "petite", "fort": "forte",
    "joli": "jolie", "poli": "polie", "gentil": "gentille",
    "gai": "gaie", "vrai": "vraie",
    "premier": "première", "dernier": "dernière", "léger": "légère",
    "fatal": "fatale", "final": "finale", "principal": "principale",
    "loyal": "loyale", "banal": "banale", "natal": "natale",
}

# Conjugaison auxiliaires (présent, indicatif)
AUXILIAIRES = {
    "être": {
        "je": "suis", "tu": "es", "il": "est", "elle": "est",
        "on": "est", "nous": "sommes", "vous": "êtes",
        "ils": "sont", "elles": "sont"
    },
    "avoir": {
        "je": "ai", "tu": "as", "il": "a", "elle": "a",
        "on": "a", "nous": "avons", "vous": "avez",
        "ils": "ont", "elles": "ont"
    }
}

# Jours et mois
JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
MOIS = ["", "janvier", "février", "mars", "avril", "mai", "juin",
        "juillet", "août", "septembre", "octobre", "novembre", "décembre"]

# Nombres en lettres (0–99)
UNITES = ["", "un", "deux", "trois", "quatre", "cinq", "six", "sept",
          "huit", "neuf", "dix", "onze", "douze", "treize", "quatorze",
          "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf"]
DIZAINES = ["", "", "vingt", "trente", "quarante", "cinquante",
            "soixante", "soixante", "quatre-vingts", "quatre-vingt"]


# ============================================================
# MOTEUR MORPHOLOGIQUE
# ============================================================

class FrenchMorphology:

    # ----------------------------------------------------------
    # VOYELLES ET H MUET
    # ----------------------------------------------------------

    VOYELLES = set("aeiouéèêëàâîïôùûü")

    def commence_par_voyelle(self, mot: str) -> bool:
        """Vrai si le mot commence par une voyelle ou un h muet."""
        if not mot:
            return False
        mot_lower = mot.lower().strip("'\"")
        first = mot_lower[0]

        if first in self.VOYELLES:
            return True

        if first == "h":
            # h muet : élision ; h aspiré : pas d'élision
            return mot_lower in H_MUET or not mot_lower in H_ASPIRE

        return False

    # ----------------------------------------------------------
    # ARTICLES
    # ----------------------------------------------------------

    def article(self, mot: str, type_art: str = "def",
                genre: str = "masc", nombre: str = "sing") -> str:
        """
        Retourne l'article correct avec élision si nécessaire.

        type_art : "def" (défini), "indef" (indéfini), "part" (partitif)
        genre    : "masc" | "fem"
        nombre   : "sing" | "plur"
        """
        voyelle = self.commence_par_voyelle(mot)

        if nombre == "plur":
            return "les" if type_art == "def" else "des"

        if type_art == "def":
            if voyelle:
                return "l'"
            return "le" if genre == "masc" else "la"

        elif type_art == "indef":
            return "un" if genre == "masc" else "une"

        elif type_art == "part":
            if voyelle:
                return "de l'"
            return "du" if genre == "masc" else "de la"

        return ""

    def contraction(self, prep: str, article: str, mot: str) -> str:
        """
        Gère les contractions : de+le=du, de+les=des, à+le=au, à+les=aux,
        avec élision devant voyelle.
        """
        voyelle = self.commence_par_voyelle(mot)

        if prep == "de":
            if article in ("le", "la") and voyelle:
                return "de l'"
            if article == "le":
                return "du"
            if article == "les":
                return "des"
            if article == "la":
                return "de la"

        elif prep == "à":
            if (article in ("le", "la")) and voyelle:
                return "à l'"
            if article == "le":
                return "au"
            if article == "les":
                return "aux"
            if article == "la":
                return "à la"

        return f"{prep} {article}"

    # ----------------------------------------------------------
    # PLURIEL
    # ----------------------------------------------------------

    def pluriel(self, mot: str, genre: str = "masc") -> str:
        """Retourne la forme plurielle du mot."""
        mot_lower = mot.lower()

        # Irréguliers
        if mot_lower in PLURIELS_IRREGULIERS:
            return PLURIELS_IRREGULIERS[mot_lower]

        # Déjà au pluriel (-s, -x, -z)
        if mot_lower[-1] in ("s", "x", "z"):
            return mot

        # -al → -aux (sauf exceptions)
        if mot_lower.endswith("al"):
            exceptions_al = {"bal", "carnaval", "festival", "récital", "régal",
                              "choral", "natal", "final", "banal", "fatal", "naval"}
            if mot_lower not in exceptions_al:
                return mot[:-2] + "aux"

        # -eau → -eaux
        if mot_lower.endswith("eau"):
            return mot + "x"

        # -eu → -eux (sauf bleu, pneu)
        if mot_lower.endswith("eu") and mot_lower not in ("bleu", "pneu"):
            return mot + "x"

        # -ou → -ous (sauf les 7 en -oux)
        if mot_lower.endswith("ou") and mot_lower not in (
            "bijou", "caillou", "chou", "genou", "hibou", "joujou", "pou"
        ):
            return mot + "s"

        # Règle générale : + s
        return mot + "s"

    # ----------------------------------------------------------
    # FÉMININ
    # ----------------------------------------------------------

    def feminin(self, mot: str) -> str:
        """Retourne la forme féminine du nom ou adjectif."""
        mot_lower = mot.lower()

        if mot_lower in FEMININS_IRREGULIERS:
            return FEMININS_IRREGULIERS[mot_lower]
        if mot_lower in ADJ_IRREGULIERS:
            return ADJ_IRREGULIERS[mot_lower]

        # -eur → -euse (verbes d'action)
        if mot_lower.endswith("eur"):
            return mot[:-3] + "euse"

        # -teur → parfois -trice (heuristique)
        if mot_lower.endswith("teur"):
            return mot[:-4] + "trice"

        # -er → -ère
        if mot_lower.endswith("er") and not mot_lower.endswith("ier"):
            return mot[:-2] + "ère"
        if mot_lower.endswith("ier"):
            return mot[:-3] + "ière"

        # -ien → -ienne
        if mot_lower.endswith("ien"):
            return mot + "ne"

        # -on → -onne
        if mot_lower.endswith("on") and not mot_lower.endswith("ion"):
            return mot + "ne"

        # -an → -ane ou -anne (heuristique : paysan → paysanne)
        if mot_lower.endswith("an"):
            return mot + "ne"

        # -et → -ette
        if mot_lower.endswith("et"):
            return mot + "te"

        # -el → -elle
        if mot_lower.endswith("el"):
            return mot + "le"

        # -if → -ive
        if mot_lower.endswith("if"):
            return mot[:-2] + "ive"

        # -eux → -euse
        if mot_lower.endswith("eux"):
            return mot[:-3] + "euse"

        # -f → -ve (bref → brève)
        if mot_lower.endswith("f") and not mot_lower.endswith("if"):
            return mot[:-1] + "ve"

        # -e déjà au féminin
        if mot_lower.endswith("e"):
            return mot

        # Règle générale : + e
        return mot + "e"

    # ----------------------------------------------------------
    # ACCORD D'ADJECTIF
    # ----------------------------------------------------------

    def accord_adj(self, adj: str, genre: str = "masc",
                   nombre: str = "sing") -> str:
        """Retourne l'adjectif accordé en genre et nombre."""
        adj_lower = adj.lower()

        # Forme de base : masculin singulier
        if genre == "masc" and nombre == "sing":
            return adj

        # Féminin singulier
        if genre == "fem" and nombre == "sing":
            if adj_lower in ADJ_IRREGULIERS:
                base = ADJ_IRREGULIERS[adj_lower]
            else:
                base = self.feminin(adj)
        else:
            base = adj

        # Pluriel
        if nombre == "plur":
            return self.pluriel(base, genre)

        return base

    # ----------------------------------------------------------
    # MAJUSCULE
    # ----------------------------------------------------------

    @staticmethod
    def majuscule(texte: str) -> str:
        """Met en majuscule la première lettre d'une phrase."""
        if not texte:
            return texte
        return texte[0].upper() + texte[1:]

    # ----------------------------------------------------------
    # ÉLISION DANS UN TEXTE
    # ----------------------------------------------------------

    def elider(self, texte: str) -> str:
        """
        Applique les élisions dans un texte déjà construit.
        Exemples : "de le" → "du", "le ami" → "l'ami"
        """
        # de + le → du
        texte = re.sub(r"\bde le\b", "du", texte)
        # de + les → des
        texte = re.sub(r"\bde les\b", "des", texte)
        # à + le → au
        texte = re.sub(r"\bà le\b", "au", texte)
        # à + les → aux
        texte = re.sub(r"\bà les\b", "aux", texte)

        # le/la/de/me/te/se/ne devant voyelle → élision
        elision_map = {
            r"\ble ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_le,
            r"\bla ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_la,
            r"\bde ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_de,
            r"\bme ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_me,
            r"\bte ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_te,
            r"\bse ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_se,
            r"\bne ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_ne,
            r"\bje ([aeiouéèêëàâîïôùûü\w]*)\b": self._elide_je,
        }

        for pattern, replacer in elision_map.items():
            texte = re.sub(pattern, replacer, texte, flags=re.IGNORECASE)

        return texte

    def _elide_le(self, m):
        mot = m.group(1)
        return f"l'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    def _elide_la(self, m):
        mot = m.group(1)
        return f"l'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    def _elide_de(self, m):
        mot = m.group(1)
        return f"d'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    def _elide_me(self, m):
        mot = m.group(1)
        return f"m'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    def _elide_te(self, m):
        mot = m.group(1)
        return f"t'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    def _elide_se(self, m):
        mot = m.group(1)
        return f"s'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    def _elide_ne(self, m):
        mot = m.group(1)
        return f"n'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    def _elide_je(self, m):
        mot = m.group(1)
        return f"j'{mot}" if self.commence_par_voyelle(mot) else m.group(0)

    # ----------------------------------------------------------
    # NOMBRES EN LETTRES
    # ----------------------------------------------------------

    def nombre_en_lettres(self, n: int, genre: str = "masc") -> str:
        """Convertit un entier (0–999) en lettres françaises."""
        if n < 0:
            return f"moins {self.nombre_en_lettres(-n, genre)}"

        if n == 0:
            return "zéro"

        if n < 20:
            mot = UNITES[n]
            if n == 1 and genre == "fem":
                return "une"
            return mot

        if n < 100:
            dizaine = n // 10
            unite = n % 10

            if dizaine == 7:  # soixante-dix
                base = "soixante"
                return f"{base}-{UNITES[10 + unite]}" if unite > 0 else "soixante-dix"

            if dizaine == 8:  # quatre-vingts
                if unite == 0:
                    return "quatre-vingts"
                return f"quatre-vingt-{UNITES[unite]}"

            if dizaine == 9:  # quatre-vingt-dix
                return f"quatre-vingt-{UNITES[10 + unite]}"

            base = DIZAINES[dizaine]
            if unite == 0:
                return base
            if unite == 1:
                return f"{base} et un" if genre == "masc" else f"{base} et une"
            return f"{base}-{UNITES[unite]}"

        if n < 1000:
            centaines = n // 100
            reste = n % 100
            if centaines == 1:
                prefix = "cent"
            else:
                prefix = f"{UNITES[centaines]} cents" if reste == 0 else f"{UNITES[centaines]} cent"
            if reste == 0:
                return prefix
            return f"{prefix} {self.nombre_en_lettres(reste, genre)}"

        return str(n)  # Au-delà de 999, on retourne le chiffre

    # ----------------------------------------------------------
    # HEURE EN LETTRES
    # ----------------------------------------------------------

    def heure_en_lettres(self, heures: int, minutes: int = 0) -> str:
        """
        Convertit une heure en texte naturel français.
        Ex: heure_en_lettres(14, 30) → "quatorze heures et demie"
        """
        h_str = self.nombre_en_lettres(heures)

        if minutes == 0:
            return f"{h_str} heure{'s' if heures != 1 else ''}"
        elif minutes == 15:
            return f"{h_str} heure{'s' if heures != 1 else ''} et quart"
        elif minutes == 30:
            return f"{h_str} heure{'s' if heures != 1 else ''} et demie"
        elif minutes == 45:
            h_suivante = (heures + 1) % 24
            return f"{self.nombre_en_lettres(h_suivante)} heure{'s' if h_suivante != 1 else ''} moins le quart"
        else:
            m_str = self.nombre_en_lettres(minutes)
            return f"{h_str} heure{'s' if heures != 1 else ''} {m_str}"

    # ----------------------------------------------------------
    # DATE EN LETTRES
    # ----------------------------------------------------------

    def date_en_lettres(self, jour: int, mois: int, annee: int,
                        jour_semaine: Optional[int] = None) -> str:
        """
        Convertit une date en texte.
        Ex: date_en_lettres(15, 3, 2024, 4) → "vendredi quinze mars deux mille vingt-quatre"
        """
        j_str = "premier" if jour == 1 else self.nombre_en_lettres(jour)
        m_str = MOIS[mois]
        a_str = self._annee_en_lettres(annee)

        if jour_semaine is not None:
            js_str = JOURS[jour_semaine % 7]
            return f"{js_str} {j_str} {m_str} {a_str}"

        return f"{j_str} {m_str} {a_str}"

    def _annee_en_lettres(self, annee: int) -> str:
        """Convertit une année en lettres."""
        if annee >= 2000:
            reste = annee - 2000
            if reste == 0:
                return "deux mille"
            return f"deux mille {self.nombre_en_lettres(reste)}"
        elif annee >= 1900:
            reste = annee - 1900
            if reste == 0:
                return "dix-neuf cents"
            return f"dix-neuf cent {self.nombre_en_lettres(reste)}"
        return str(annee)

    # ----------------------------------------------------------
    # SAISON
    # ----------------------------------------------------------

    GENRE_SAISON = {
        "printemps": "masc",
        "été": "masc",
        "automne": "masc",
        "hiver": "masc"
    }

    def article_saison(self, saison: str) -> str:
        """Retourne la préposition/article correct pour une saison."""
        articles = {
            "printemps": "au ",
            "été": "en ",
            "automne": "en ",
            "hiver": "en "
        }
        return articles.get(saison.lower(), "en ")
